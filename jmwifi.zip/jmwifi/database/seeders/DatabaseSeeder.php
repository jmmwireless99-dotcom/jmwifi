<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Plan;
use App\Models\SystemSetting;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Default admin login — CHANGE THIS PASSWORD IMMEDIATELY after first login.
        User::firstOrCreate(
            ['email' => 'admin@jmwifi.local'],
            [
                'name' => 'JM WIFI Administrator',
                'password' => Hash::make('ChangeMe!2026'),
                'role' => 'admin',
                'is_active' => true,
            ]
        );

        // Example staff account
        User::firstOrCreate(
            ['email' => 'staff@jmwifi.local'],
            [
                'name' => 'JM WIFI Staff',
                'password' => Hash::make('StaffPass!2026'),
                'role' => 'staff',
                'is_active' => true,
            ]
        );

        // A couple of sample plans so the Clients form isn't empty on first run
        Plan::firstOrCreate(
            ['name' => 'Home 25Mbps'],
            [
                'monthly_rate' => 999.00,
                'speed_down' => '25M',
                'speed_up' => '5M',
                'mikrotik_profile_name' => 'default',
                'is_active' => true,
            ]
        );

        Plan::firstOrCreate(
            ['name' => 'Home 50Mbps'],
            [
                'monthly_rate' => 1499.00,
                'speed_down' => '50M',
                'speed_up' => '10M',
                'mikrotik_profile_name' => 'default-50m',
                'is_active' => true,
            ]
        );

        // Default system settings
        SystemSetting::set('company_name', 'JM WIFI', 'string', 'general');
        SystemSetting::set('support_contact', '0917-000-0000', 'string', 'general');
        SystemSetting::set('billing_cycle_days', 30, 'integer', 'billing');
        SystemSetting::set('expiry_warning_days', 3, 'integer', 'billing');
    }
}
