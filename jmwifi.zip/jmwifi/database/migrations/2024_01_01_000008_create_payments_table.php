<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * payments table
     * Records every payment attempt/result — both PayMongo (GCash) checkouts
     * and manually-submitted proof-of-payment entries.
     */
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->string('payment_reference')->unique(); // internal ref, e.g. PAY-2026-00001
            $table->foreignId('client_id')->constrained('clients')->cascadeOnDelete();
            $table->foreignId('invoice_id')->nullable()->constrained('invoices')->nullOnDelete();

            $table->decimal('amount', 10, 2);
            $table->enum('method', ['gcash', 'paymongo_card', 'manual_gcash', 'cash', 'other'])
                  ->default('gcash');
            $table->enum('purpose', ['renewal', 'advance', 'partial', 'other'])->default('renewal');

            // PayMongo specific fields
            $table->string('paymongo_checkout_id')->nullable()->index();
            $table->string('paymongo_payment_id')->nullable()->index();
            $table->string('paymongo_status')->nullable(); // awaiting_payment_method, paid, expired, etc.
            $table->text('paymongo_checkout_url')->nullable();
            $table->json('paymongo_raw_response')->nullable();

            // Manual proof-of-payment
            $table->string('proof_image_path')->nullable();
            $table->foreignId('verified_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('verified_at')->nullable();

            $table->enum('status', ['pending', 'paid', 'failed', 'expired', 'refunded'])->default('pending');
            $table->timestamp('paid_at')->nullable();
            $table->text('notes')->nullable();

            $table->timestamps();

            $table->index(['client_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
