<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * routers table
     * One row per MikroTik device. Supports multiple routers/branches.
     * api_password is encrypted at the Eloquent model level (cast).
     */
    public function up(): void
    {
        Schema::create('routers', function (Blueprint $table) {
            $table->id();
            $table->string('name');                    // e.g. "Main Office MikroTik"
            $table->string('ip_address');               // RouterOS API host
            $table->unsignedInteger('api_port')->default(8728); // 8728 plain, 8729 SSL
            $table->boolean('use_ssl')->default(false);
            $table->string('api_username');
            $table->text('api_password');                // encrypted cast
            $table->enum('client_mode', ['pppoe', 'ipoe', 'both'])->default('both');

            // Names of RouterOS objects this app will manage. Configurable
            // because every ISP names their profiles/lists differently.
            $table->string('normal_pppoe_profile')->default('default');
            $table->string('expired_pppoe_profile')->default('EXPIRED');
            $table->string('expired_address_list')->default('EXPIRED-CLIENTS');

            $table->enum('status', ['online', 'offline', 'unknown'])->default('unknown');
            $table->timestamp('last_checked_at')->nullable();
            $table->text('last_error')->nullable();

            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('routers');
    }
};
