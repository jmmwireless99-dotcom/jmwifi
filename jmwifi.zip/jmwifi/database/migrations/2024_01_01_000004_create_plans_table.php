<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('plans', function (Blueprint $table) {
            $table->id();
            $table->string('name');                  // e.g. "Home 25Mbps"
            $table->decimal('monthly_rate', 10, 2);
            $table->string('speed_down')->nullable(); // "25M"
            $table->string('speed_up')->nullable();   // "5M"
            $table->text('description')->nullable();

            // RouterOS profile/queue name this plan maps to when active
            $table->string('mikrotik_profile_name')->nullable();
            $table->string('mikrotik_queue_name')->nullable(); // for IPoE simple queue template

            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('plans');
    }
};
