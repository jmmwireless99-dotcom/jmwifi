<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * mikrotik_logs table
     * Audit trail of every action/sync attempt against a router, success or fail.
     * Critical for debugging "why didn't this client reconnect" support issues.
     */
    public function up(): void
    {
        Schema::create('mikrotik_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->nullable()->constrained('routers')->nullOnDelete();
            $table->foreignId('client_id')->nullable()->constrained('clients')->nullOnDelete();

            $table->enum('action', [
                'sync_pppoe',
                'sync_ipoe',
                'enable_client',
                'disable_client',
                'move_to_expired_profile',
                'restore_normal_profile',
                'add_to_expired_list',
                'remove_from_expired_list',
                'disconnect_session',
                'connection_check',
                'router_health_check',
                'other',
            ]);

            $table->enum('status', ['success', 'failed'])->default('success');
            $table->text('message')->nullable();
            $table->json('payload')->nullable(); // raw request/response context for debugging

            $table->timestamps();

            $table->index(['router_id', 'created_at']);
            $table->index(['client_id', 'created_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mikrotik_logs');
    }
};
