<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * clients table
     * Core subscriber record. Clients authenticate via the `client` guard
     * (see config/auth.php) using account_number + password.
     */
    public function up(): void
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->id();
            $table->string('account_number')->unique(); // human-friendly login id, e.g. JM-00001
            $table->string('full_name');
            $table->string('address')->nullable();
            $table->string('contact_number')->nullable();
            $table->string('email')->nullable();
            $table->string('password'); // client portal login

            $table->foreignId('plan_id')->nullable()->constrained('plans')->nullOnDelete();
            $table->foreignId('router_id')->nullable()->constrained('routers')->nullOnDelete();

            $table->enum('connection_type', ['pppoe', 'ipoe'])->default('pppoe');

            // PPPoE identity
            $table->string('pppoe_username')->nullable()->unique();
            $table->string('pppoe_password')->nullable();

            // IPoE / DHCP identity
            $table->string('mac_address')->nullable()->unique();
            $table->string('ip_address')->nullable();

            $table->decimal('monthly_rate_override', 10, 2)->nullable(); // optional override of plan rate

            $table->date('due_date')->nullable();          // day-of-month billing is due
            $table->date('expiration_date')->nullable();   // hard cutoff date
            $table->date('last_payment_date')->nullable();

            // Connectivity / billing state machine
            $table->enum('billing_status', ['active', 'expired', 'suspended', 'pending'])->default('pending');
            $table->enum('connection_status', ['online', 'offline', 'router_offline', 'unknown'])
                  ->default('unknown');
            $table->timestamp('last_seen_online_at')->nullable();
            $table->timestamp('last_synced_at')->nullable();

            $table->boolean('is_active')->default(true); // soft enable/disable of the account itself

            $table->timestamps();

            $table->index(['billing_status']);
            $table->index(['connection_status']);
            $table->index(['expiration_date']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('clients');
    }
};
