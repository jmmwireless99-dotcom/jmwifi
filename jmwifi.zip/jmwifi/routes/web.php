<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\ClientLoginController;

use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\ClientController;
use App\Http\Controllers\Admin\PlanController;
use App\Http\Controllers\Admin\RouterController;
use App\Http\Controllers\Admin\PaymentController;
use App\Http\Controllers\Admin\InvoiceController;
use App\Http\Controllers\Admin\MapController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\Admin\LogController;

use App\Http\Controllers\Staff\DashboardController as StaffDashboardController;

use App\Http\Controllers\Client\AccountController;
use App\Http\Controllers\Client\BillingController;

use App\Http\Controllers\Public\ExpiredPortalController;
use App\Http\Controllers\Public\PaymentResultController;

/*
|--------------------------------------------------------------------------
| Public
|--------------------------------------------------------------------------
*/
Route::get('/', fn () => redirect()->route('login'));

Route::get('/payment/success', [PaymentResultController::class, 'success'])->name('payment.success');
Route::get('/payment/failed', [PaymentResultController::class, 'failed'])->name('payment.failed');

Route::middleware('auth:client')->group(function () {
    Route::get('/expired', [ExpiredPortalController::class, 'show'])->name('client.expired');
    Route::post('/expired/pay', [ExpiredPortalController::class, 'createPayment'])->name('client.expired.pay');
});
// Allow guests to view the expired page too (generic message), so a direct
// link still resolves instead of 403ing.
Route::get('/expired-info', [ExpiredPortalController::class, 'show']);

/*
|--------------------------------------------------------------------------
| Admin / Staff Auth (shared `users` table, `web` guard)
|--------------------------------------------------------------------------
*/
Route::middleware('guest:web')->group(function () {
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [LoginController::class, 'login']);
});
Route::post('/logout', [LoginController::class, 'logout'])->name('logout')->middleware('auth:web');

/*
|--------------------------------------------------------------------------
| Client Portal Auth (`clients` table, `client` guard)
|--------------------------------------------------------------------------
*/
Route::middleware('guest:client')->group(function () {
    Route::get('/client/login', [ClientLoginController::class, 'showLoginForm'])->name('client.login');
    Route::post('/client/login', [ClientLoginController::class, 'login']);
});
Route::post('/client/logout', [ClientLoginController::class, 'logout'])
    ->name('client.logout')
    ->middleware('auth:client');

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/
Route::middleware(['auth:web', 'is.admin.or.staff'])->prefix('admin')->name('admin.')->group(function () {

    Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

    // Clients — viewable/manageable by both admin and staff
    Route::resource('clients', ClientController::class);
    Route::post('clients/{client}/refresh-status', [ClientController::class, 'refreshStatus'])->name('clients.refresh-status');
    Route::post('clients/{client}/toggle-suspend', [ClientController::class, 'toggleSuspend'])->name('clients.toggle-suspend');

    // Payments — viewable/manageable by both
    Route::get('payments', [PaymentController::class, 'index'])->name('payments.index');
    Route::get('payments/{payment}', [PaymentController::class, 'show'])->name('payments.show');
    Route::post('payments/manual', [PaymentController::class, 'storeManual'])->name('payments.manual');
    Route::post('payments/{payment}/approve-proof', [PaymentController::class, 'approveProof'])->name('payments.approve-proof');
    Route::post('payments/{payment}/reject-proof', [PaymentController::class, 'rejectProof'])->name('payments.reject-proof');
    Route::post('payments/{payment}/verify-paymongo', [PaymentController::class, 'verifyWithPayMongo'])->name('payments.verify-paymongo');
    Route::get('payments/{payment}/proof-image', [PaymentController::class, 'proofImage'])->name('payments.proof-image');

    // Invoices
    Route::resource('invoices', InvoiceController::class)->except(['edit', 'update', 'create']);

    // Map
    Route::get('map', [MapController::class, 'index'])->name('map.index');
    Route::get('map/pins', [MapController::class, 'pins'])->name('map.pins');
    Route::post('map/clients/{client}/location', [MapController::class, 'updateLocation'])->name('map.update-location');

    // Logs
    Route::get('logs', [LogController::class, 'index'])->name('logs.index');

    // --- Admin-only sub-area ---
    Route::middleware('is.admin.only')->group(function () {
        Route::resource('plans', PlanController::class)->except(['create', 'edit', 'show']);
        Route::resource('routers', RouterController::class)->except(['create', 'edit', 'show']);
        Route::post('routers/{router}/test-connection', [RouterController::class, 'testConnection'])->name('routers.test-connection');
        Route::post('routers/{router}/sync-now', [RouterController::class, 'syncNow'])->name('routers.sync-now');

        Route::get('settings', [SettingsController::class, 'index'])->name('settings.index');
        Route::post('settings', [SettingsController::class, 'update'])->name('settings.update');
        Route::post('settings/users', [SettingsController::class, 'storeUser'])->name('settings.users.store');
        Route::post('settings/users/{user}/toggle', [SettingsController::class, 'toggleUser'])->name('settings.users.toggle');
    });
});

/*
|--------------------------------------------------------------------------
| Staff Routes (lightweight dashboard; shared admin.* routes above handle
| clients/payments which staff can also access via is.admin.or.staff)
|--------------------------------------------------------------------------
*/
Route::middleware(['auth:web', 'is.admin.or.staff'])->prefix('staff')->name('staff.')->group(function () {
    Route::get('/dashboard', [StaffDashboardController::class, 'index'])->name('dashboard');
});

/*
|--------------------------------------------------------------------------
| Client Portal Routes
|--------------------------------------------------------------------------
*/
Route::middleware('is.client')->prefix('client')->name('client.')->group(function () {
    Route::get('/dashboard', [AccountController::class, 'dashboard'])->name('dashboard');
    Route::get('/account', [AccountController::class, 'myAccount'])->name('account');
    Route::post('/account', [AccountController::class, 'updateProfile'])->name('account.update');

    Route::get('/pay-bills', [BillingController::class, 'payBills'])->name('pay-bills');
    Route::get('/advance-payment', [BillingController::class, 'advancePayment'])->name('advance-payment');
    Route::post('/checkout', [BillingController::class, 'checkout'])->name('checkout');
    Route::post('/submit-proof', [BillingController::class, 'submitProof'])->name('submit-proof');

    Route::get('/payment-history', [BillingController::class, 'history'])->name('payment-history');
    Route::get('/receipt/{payment}', [BillingController::class, 'receipt'])->name('receipt');
});
