<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Webhooks\PayMongoWebhookController;

/*
|--------------------------------------------------------------------------
| Webhook Routes
|--------------------------------------------------------------------------
| Loaded separately from web.php so it's obvious these routes are
| CSRF-exempt (see bootstrap/app.php -> validateCsrfTokens except list)
| and authenticated purely via PayMongo's HMAC signature, not sessions.
*/

Route::post('/webhooks/paymongo', [PayMongoWebhookController::class, 'handle'])->name('webhooks.paymongo');
