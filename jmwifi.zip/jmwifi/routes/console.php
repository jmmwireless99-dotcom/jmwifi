<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

/*
|--------------------------------------------------------------------------
| Scheduled Tasks
|--------------------------------------------------------------------------
| Requires a real cron entry on the VPS running every minute:
|   * * * * * cd /path/to/jmwifi-billing && php artisan schedule:run >> /dev/null 2>&1
| See docs/INSTALL.md for the full crontab setup.
*/

// Pull live online/offline + lease/secret state from every router.
Schedule::command('mikrotik:sync')
    ->everyFiveMinutes()
    ->withoutOverlapping()
    ->onOneServer();

// Flip clients past their expiration_date to 'expired' and suspend them.
Schedule::command('clients:check-expired')
    ->dailyAt('00:05')
    ->withoutOverlapping()
    ->onOneServer();

// Send "your account expires soon" warnings.
Schedule::command('clients:warn-expiring')
    ->dailyAt('08:00')
    ->withoutOverlapping()
    ->onOneServer();
