<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        commands: __DIR__ . '/../routes/console.php',
        then: function () {
            \Illuminate\Support\Facades\Route::middleware('web')
                ->group(__DIR__ . '/../routes/webhooks.php');
        },
    )
    ->withMiddleware(function (Middleware $middleware) {

        $middleware->alias([
            'is.admin.or.staff' => \App\Http\Middleware\IsAdminOrStaff::class,
            'is.admin.only' => \App\Http\Middleware\IsAdminOnlyAction::class,
            'is.admin' => \App\Http\Middleware\IsAdmin::class,
            'is.client' => \App\Http\Middleware\IsClient::class,
        ]);

        // PayMongo posts to our webhook with no CSRF token (it's a
        // server-to-server call authenticated by HMAC signature instead —
        // see PayMongoService::verifyWebhookSignature()).
        $middleware->validateCsrfTokens(except: [
            'webhooks/paymongo',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
