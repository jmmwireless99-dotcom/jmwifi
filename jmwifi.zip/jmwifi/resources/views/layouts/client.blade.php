<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'My Account') - JM WIFI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen flex flex-col">
<header class="bg-blue-700 text-white">
    <div class="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
        <div class="font-bold text-lg">JM WIFI</div>
        @auth('client')
            <nav class="flex gap-4 text-sm">
                <a href="{{ route('client.dashboard') }}" class="hover:underline">Dashboard</a>
                <a href="{{ route('client.account') }}" class="hover:underline">My Account</a>
                <a href="{{ route('client.pay-bills') }}" class="hover:underline">Pay Bills</a>
                <a href="{{ route('client.payment-history') }}" class="hover:underline">History</a>
                <form method="POST" action="{{ route('client.logout') }}" class="inline">
                    @csrf
                    <button class="hover:underline">Logout</button>
                </form>
            </nav>
        @endauth
    </div>
</header>

<main class="flex-1 max-w-3xl w-full mx-auto px-4 py-8">
    @if(session('success'))
        <div class="mb-4 px-4 py-3 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 text-sm">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="mb-4 px-4 py-3 rounded-lg bg-red-50 text-red-700 border border-red-200 text-sm">{{ session('error') }}</div>
    @endif
    @if($errors->any())
        <div class="mb-4 px-4 py-3 rounded-lg bg-red-50 text-red-700 border border-red-200 text-sm">
            <ul class="list-disc list-inside">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @yield('content')
</main>

<footer class="text-center text-xs text-slate-400 py-4">
    &copy; {{ date('Y') }} JM WIFI. All rights reserved.
</footer>
</body>
</html>
