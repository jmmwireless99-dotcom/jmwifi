<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') - JM WIFI Billing</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
    @stack('head')
</head>
<body class="bg-slate-50 text-slate-800">
<div class="flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-64 bg-slate-900 text-slate-200 flex-shrink-0 flex flex-col">
        <div class="px-6 py-5 border-b border-slate-700">
            <div class="text-lg font-bold text-white">JM WIFI</div>
            <div class="text-xs text-slate-400">Billing System</div>
        </div>
        <nav class="flex-1 px-3 py-4 space-y-1 text-sm">
            @php($user = auth('web')->user())
            <a href="{{ route('admin.dashboard') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.dashboard') ? 'bg-slate-800 text-white' : '' }}">📊 Dashboard</a>
            <a href="{{ route('admin.clients.index') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.clients.*') ? 'bg-slate-800 text-white' : '' }}">👥 Clients</a>
            <a href="{{ route('admin.payments.index') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.payments.*') ? 'bg-slate-800 text-white' : '' }}">💳 Payments</a>
            <a href="{{ route('admin.invoices.index') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.invoices.*') ? 'bg-slate-800 text-white' : '' }}">🧾 Invoices</a>
            <a href="{{ route('admin.map.index') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.map.*') ? 'bg-slate-800 text-white' : '' }}">🗺️ Map</a>
            <a href="{{ route('admin.logs.index') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.logs.*') ? 'bg-slate-800 text-white' : '' }}">📋 MikroTik Logs</a>

            @if($user && $user->isAdmin())
                <div class="pt-3 mt-3 border-t border-slate-700 text-xs uppercase text-slate-500 px-3">Admin</div>
                <a href="{{ route('admin.plans.index') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.plans.*') ? 'bg-slate-800 text-white' : '' }}">📦 Plans</a>
                <a href="{{ route('admin.routers.index') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.routers.*') ? 'bg-slate-800 text-white' : '' }}">📡 Routers</a>
                <a href="{{ route('admin.settings.index') }}" class="block px-3 py-2 rounded-lg hover:bg-slate-800 {{ request()->routeIs('admin.settings.*') ? 'bg-slate-800 text-white' : '' }}">⚙️ Settings</a>
            @endif
        </nav>
        <div class="px-3 py-4 border-t border-slate-700">
            <div class="px-3 text-xs text-slate-400 mb-2">{{ $user->name ?? '' }} ({{ $user->role ?? '' }})</div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button class="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-800 text-red-300">🚪 Logout</button>
            </form>
        </div>
    </aside>

    <!-- Main -->
    <div class="flex-1 flex flex-col min-w-0">
        <header class="bg-white border-b border-slate-200 px-8 py-4 flex items-center justify-between">
            <h1 class="text-xl font-semibold text-slate-800">@yield('header', 'Dashboard')</h1>
        </header>

        <main class="flex-1 p-8">
            @if(session('success'))
                <div class="mb-4 px-4 py-3 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 text-sm">{{ session('success') }}</div>
            @endif
            @if(session('error'))
                <div class="mb-4 px-4 py-3 rounded-lg bg-red-50 text-red-700 border border-red-200 text-sm">{{ session('error') }}</div>
            @endif
            @if($errors->any())
                <div class="mb-4 px-4 py-3 rounded-lg bg-red-50 text-red-700 border border-red-200 text-sm">
                    <ul class="list-disc list-inside">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @yield('content')
        </main>
    </div>
</div>
@stack('scripts')
</body>
</html>
