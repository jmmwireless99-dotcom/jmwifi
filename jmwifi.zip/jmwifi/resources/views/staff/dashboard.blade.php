@extends('layouts.admin')
@section('title', 'Staff Dashboard')
@section('header', 'Staff Dashboard')

@section('content')
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <div class="text-xs uppercase text-slate-400 mb-1">Total Clients</div>
        <div class="text-2xl font-bold">{{ $stats['total_clients'] }}</div>
    </div>
    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <div class="text-xs uppercase text-slate-400 mb-1">Active</div>
        <div class="text-2xl font-bold text-emerald-600">{{ $stats['active_clients'] }}</div>
    </div>
    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <div class="text-xs uppercase text-slate-400 mb-1">Expired</div>
        <div class="text-2xl font-bold text-red-600">{{ $stats['expired_clients'] }}</div>
    </div>
    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <div class="text-xs uppercase text-slate-400 mb-1">Online</div>
        <div class="text-2xl font-bold text-blue-600">{{ $stats['online_clients'] }}</div>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <h3 class="font-semibold mb-3">Pending Proof-of-Payment Reviews</h3>
        <div class="space-y-2 text-sm">
            @forelse($pendingProofs as $payment)
            <div class="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
                <div>
                    <div class="font-medium">{{ $payment->client->full_name }}</div>
                    <div class="text-xs text-slate-400">₱{{ number_format($payment->amount, 2) }} · {{ $payment->created_at->diffForHumans() }}</div>
                </div>
                <a href="{{ route('admin.payments.show', $payment) }}" class="text-blue-600 hover:underline text-sm">Review</a>
            </div>
            @empty
            <div class="text-slate-400">Nothing pending.</div>
            @endforelse
        </div>
    </div>

    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <h3 class="font-semibold mb-3">Recent Payments</h3>
        <div class="space-y-2 text-sm">
            @forelse($recentPayments as $payment)
            <div class="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
                <div>{{ $payment->client->full_name ?? 'N/A' }}</div>
                <div class="text-emerald-600 font-medium">₱{{ number_format($payment->amount, 2) }}</div>
            </div>
            @empty
            <div class="text-slate-400">No payments yet.</div>
            @endforelse
        </div>
    </div>
</div>
@endsection
