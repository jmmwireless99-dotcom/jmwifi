@extends('layouts.client')
@section('title', 'Advance Payment')

@section('content')
<div class="bg-white rounded-xl border border-slate-200 p-6">
    <h2 class="font-semibold mb-2">Advance Payment</h2>
    <p class="text-sm text-slate-400 mb-6">Pay ahead for multiple months. Your expiration date will be extended automatically based on the amount paid.</p>

    <form method="POST" action="{{ route('client.checkout') }}" class="space-y-4">
        @csrf
        <input type="hidden" name="purpose" value="advance">

        <div>
            <label class="block text-sm font-medium mb-2">Number of Months</label>
            <select id="months" class="w-full px-3 py-2 border border-slate-300 rounded-lg" onchange="updateAmount()">
                @for($i = 1; $i <= 12; $i++)
                <option value="{{ $i }}">{{ $i }} month{{ $i > 1 ? 's' : '' }} — ₱{{ number_format($client->monthly_rate * $i, 2) }}</option>
                @endfor
            </select>
        </div>

        <input type="hidden" name="amount" id="amount" value="{{ $client->monthly_rate }}">

        <button type="submit" class="w-full px-5 py-3 bg-[#007dfe] text-white rounded-lg font-medium hover:opacity-90">
            Pay with GCash
        </button>
    </form>
</div>

<script>
const monthlyRate = {{ $client->monthly_rate }};
function updateAmount() {
    const months = document.getElementById('months').value;
    document.getElementById('amount').value = (monthlyRate * months).toFixed(2);
}
</script>
@endsection
