<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Receipt {{ $payment->payment_reference }}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>body { font-family: 'Courier New', monospace; } @media print { .no-print { display: none; } }</style>
</head>
<body class="bg-slate-100 min-h-screen flex items-center justify-center p-4">
    <div class="bg-white max-w-sm w-full p-8 rounded-lg shadow-lg">
        <div class="text-center mb-6">
            <div class="text-xl font-bold">JM WIFI</div>
            <div class="text-sm text-slate-500">Official Receipt</div>
        </div>

        <div class="border-t border-b border-dashed border-slate-300 py-4 space-y-2 text-sm">
            <div class="flex justify-between"><span>Receipt #</span><span>{{ $payment->payment_reference }}</span></div>
            <div class="flex justify-between"><span>Date</span><span>{{ $payment->paid_at->format('M d, Y h:i A') }}</span></div>
            <div class="flex justify-between"><span>Client</span><span>{{ $payment->client->full_name }}</span></div>
            <div class="flex justify-between"><span>Account #</span><span>{{ $payment->client->account_number }}</span></div>
            <div class="flex justify-between"><span>Method</span><span class="capitalize">{{ str_replace('_',' ',$payment->method) }}</span></div>
            <div class="flex justify-between"><span>Purpose</span><span class="capitalize">{{ $payment->purpose }}</span></div>
        </div>

        <div class="py-4 text-center">
            <div class="text-xs text-slate-400">AMOUNT PAID</div>
            <div class="text-3xl font-bold">₱{{ number_format($payment->amount, 2) }}</div>
        </div>

        <div class="text-center text-xs text-slate-400 mt-4">Thank you for your payment!</div>

        <button onclick="window.print()" class="no-print w-full mt-6 px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Print / Download</button>
    </div>
</body>
</html>
