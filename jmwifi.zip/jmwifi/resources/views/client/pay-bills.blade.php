@extends('layouts.client')
@section('title', 'Pay Bills')

@section('content')
<div class="bg-white rounded-xl border border-slate-200 p-6 mb-6">
    <h2 class="font-semibold mb-4">Pay Your Bill</h2>
    <div class="text-3xl font-bold text-blue-700 mb-1">₱{{ number_format($client->monthly_rate, 2) }}</div>
    <div class="text-sm text-slate-400 mb-6">{{ $client->plan->name ?? 'Internet Plan' }} — due {{ $client->due_date?->format('M d, Y') ?? 'N/A' }}</div>

    <form method="POST" action="{{ route('client.checkout') }}">
        @csrf
        <input type="hidden" name="amount" value="{{ $client->monthly_rate }}">
        <input type="hidden" name="purpose" value="renewal">
        <button type="submit" class="w-full px-5 py-3 bg-[#007dfe] text-white rounded-lg font-medium hover:opacity-90 flex items-center justify-center gap-2">
            Pay with GCash
        </button>
    </form>
</div>

<div class="bg-white rounded-xl border border-slate-200 p-6">
    <h3 class="font-semibold mb-2">Submit Manual GCash Proof of Payment</h3>
    <p class="text-sm text-slate-400 mb-4">If you already transferred payment manually via GCash, upload your receipt here for verification.</p>

    <form method="POST" action="{{ route('client.submit-proof') }}" enctype="multipart/form-data" class="space-y-3">
        @csrf
        <input type="hidden" name="purpose" value="renewal">
        <div>
            <label class="block text-sm font-medium mb-1">Amount Sent</label>
            <input type="number" step="0.01" name="amount" value="{{ $client->monthly_rate }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">GCash Reference Number</label>
            <input type="text" name="reference_number" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Screenshot of Payment</label>
            <input type="file" name="proof_image" accept="image/*" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
        </div>
        <button type="submit" class="px-5 py-2.5 bg-slate-800 text-white rounded-lg hover:bg-slate-900">Submit for Verification</button>
    </form>
</div>
@endsection
