@extends('layouts.client')
@section('title', 'My Account')

@section('content')
<div class="bg-white rounded-xl border border-slate-200 p-6 mb-6">
    <h2 class="font-semibold mb-4">My Account</h2>
    <dl class="text-sm space-y-2 mb-6">
        <div class="flex justify-between"><dt class="text-slate-400">Account Number</dt><dd class="font-mono">{{ $client->account_number }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Plan</dt><dd>{{ $client->plan->name ?? '—' }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Due Date</dt><dd>{{ $client->due_date?->format('M d, Y') ?? '—' }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Expiration Date</dt><dd>{{ $client->expiration_date?->format('M d, Y') ?? '—' }}</dd></div>
    </dl>

    <h3 class="font-semibold mb-3 pt-4 border-t border-slate-100">Update Profile</h3>
    <form method="POST" action="{{ route('client.account.update') }}" class="space-y-3">
        @csrf
        <div>
            <label class="block text-sm font-medium mb-1">Contact Number</label>
            <input type="text" name="contact_number" value="{{ old('contact_number', $client->contact_number) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Email</label>
            <input type="email" name="email" value="{{ old('email', $client->email) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Address</label>
            <input type="text" name="address" value="{{ old('address', $client->address) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">New Password (leave blank to keep current)</label>
            <input type="password" name="password" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Confirm New Password</label>
            <input type="password" name="password_confirmation" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
        </div>
        <button type="submit" class="px-5 py-2.5 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Save Changes</button>
    </form>
</div>
@endsection
