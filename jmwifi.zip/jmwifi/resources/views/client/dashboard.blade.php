@extends('layouts.client')
@section('title', 'Dashboard')

@section('content')
<div class="bg-white rounded-xl border border-slate-200 p-6 mb-6">
    <div class="flex justify-between items-start mb-4">
        <div>
            <h2 class="text-xl font-bold">{{ $client->full_name }}</h2>
            <div class="text-slate-400 text-sm font-mono">{{ $client->account_number }}</div>
        </div>
        <span class="text-xs px-3 py-1.5 rounded-full font-medium
            {{ $client->billing_status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' }}">
            {{ ucfirst($client->billing_status) }}
        </span>
    </div>

    <div class="grid grid-cols-2 gap-4 text-sm">
        <div>
            <div class="text-slate-400">Plan</div>
            <div class="font-medium">{{ $client->plan->name ?? '—' }}</div>
        </div>
        <div>
            <div class="text-slate-400">Monthly Rate</div>
            <div class="font-medium">₱{{ number_format($client->monthly_rate, 2) }}</div>
        </div>
        <div>
            <div class="text-slate-400">Due Date</div>
            <div class="font-medium">{{ $client->due_date?->format('M d, Y') ?? '—' }}</div>
        </div>
        <div>
            <div class="text-slate-400">Expires</div>
            <div class="font-medium">{{ $client->expiration_date?->format('M d, Y') ?? '—' }}</div>
        </div>
    </div>

    @if($client->daysUntilExpiration() !== null && $client->daysUntilExpiration() <= 5 && $client->daysUntilExpiration() >= 0)
    <div class="mt-4 px-4 py-3 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 text-sm">
        Your account expires in {{ $client->daysUntilExpiration() }} day(s). Please renew to avoid disconnection.
    </div>
    @endif

    <a href="{{ route('client.pay-bills') }}" class="mt-4 inline-block px-5 py-2.5 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Pay Bills</a>
</div>

<div class="bg-white rounded-xl border border-slate-200 p-6">
    <h3 class="font-semibold mb-3">Recent Payments</h3>
    <div class="space-y-2 text-sm">
        @forelse($recentPayments as $payment)
        <div class="flex justify-between items-center py-2 border-b border-slate-50 last:border-0">
            <div>
                <div>{{ $payment->created_at->format('M d, Y') }}</div>
                <div class="text-xs text-slate-400 capitalize">{{ str_replace('_',' ',$payment->method) }}</div>
            </div>
            <div class="text-right">
                <div class="font-medium">₱{{ number_format($payment->amount, 2) }}</div>
                <div class="text-xs capitalize {{ $payment->status === 'paid' ? 'text-emerald-600' : 'text-amber-600' }}">{{ $payment->status }}</div>
            </div>
        </div>
        @empty
        <div class="text-slate-400">No payments yet.</div>
        @endforelse
    </div>
    <a href="{{ route('client.payment-history') }}" class="text-blue-600 text-sm hover:underline mt-3 inline-block">View all payments →</a>
</div>
@endsection
