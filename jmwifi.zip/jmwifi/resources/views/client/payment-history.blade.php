@extends('layouts.client')
@section('title', 'Payment History')

@section('content')
<div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-slate-50">
            <tr class="text-left text-slate-500">
                <th class="px-4 py-3">Date</th>
                <th class="px-4 py-3">Amount</th>
                <th class="px-4 py-3">Method</th>
                <th class="px-4 py-3">Status</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            @forelse($payments as $payment)
            <tr class="border-t border-slate-100">
                <td class="px-4 py-3">{{ $payment->created_at->format('M d, Y') }}</td>
                <td class="px-4 py-3">₱{{ number_format($payment->amount, 2) }}</td>
                <td class="px-4 py-3 capitalize">{{ str_replace('_',' ',$payment->method) }}</td>
                <td class="px-4 py-3">
                    <span class="text-xs px-2 py-1 rounded-full {{ $payment->status === 'paid' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700' }}">{{ ucfirst($payment->status) }}</span>
                </td>
                <td class="px-4 py-3 text-right">
                    @if($payment->status === 'paid')
                    <a href="{{ route('client.receipt', $payment) }}" class="text-blue-600 hover:underline">Receipt</a>
                    @endif
                </td>
            </tr>
            @empty
            <tr><td colspan="5" class="px-4 py-8 text-center text-slate-400">No payments yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $payments->links() }}</div>
@endsection
