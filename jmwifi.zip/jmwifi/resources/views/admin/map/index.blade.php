@extends('layouts.admin')
@section('title', 'Client Map')
@section('header', 'Client Map')

@section('content')
<div class="bg-white rounded-xl border border-slate-200 p-4 mb-4 flex gap-4 text-sm">
    <div class="flex items-center gap-2"><span class="w-3 h-3 rounded-full bg-emerald-500 inline-block"></span> Active / Online</div>
    <div class="flex items-center gap-2"><span class="w-3 h-3 rounded-full bg-red-500 inline-block"></span> Expired</div>
    <div class="flex items-center gap-2"><span class="w-3 h-3 rounded-full bg-slate-400 inline-block"></span> Offline</div>
</div>

<div id="map" class="w-full rounded-xl border border-slate-200" style="height: 600px;"></div>

@if(!$googleMapsApiKey)
<div class="mt-4 px-4 py-3 rounded-lg bg-amber-50 text-amber-700 border border-amber-200 text-sm">
    No Google Maps API key configured. Set <code>GOOGLE_MAPS_API_KEY</code> in your .env file to enable the map.
</div>
@endif

@push('scripts')
<script>
let map;
const markerColors = { green: '#10b981', red: '#ef4444', gray: '#94a3b8' };

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: {{ $defaultLat }}, lng: {{ $defaultLng }} },
        zoom: 13,
    });

    fetch('{{ route('admin.map.pins') }}')
        .then(r => r.json())
        .then(pins => {
            pins.forEach(pin => {
                const marker = new google.maps.Marker({
                    position: { lat: pin.lat, lng: pin.lng },
                    map: map,
                    title: pin.name,
                    icon: {
                        path: google.maps.SymbolPath.CIRCLE,
                        fillColor: markerColors[pin.color] || markerColors.gray,
                        fillOpacity: 1,
                        strokeColor: '#fff',
                        strokeWeight: 2,
                        scale: 9,
                    },
                });

                const info = new google.maps.InfoWindow({
                    content: `<div style="font-family:Inter,sans-serif;min-width:180px">
                        <strong>${pin.name}</strong><br>
                        <span style="color:#64748b;font-size:12px">${pin.account_number} · ${pin.plan ?? ''}</span><br>
                        <span style="font-size:12px">Status: ${pin.billing_status} / ${pin.connection_status}</span><br>
                        ${pin.expiration_date ? `<span style="font-size:12px">Expires: ${pin.expiration_date}</span><br>` : ''}
                        <a href="${pin.detail_url}" style="font-size:12px;color:#2563eb">View client →</a>
                    </div>`
                });

                marker.addListener('click', () => info.open(map, marker));
            });
        });
}
window.initMap = initMap;
</script>
@if($googleMapsApiKey)
<script src="https://maps.googleapis.com/maps/api/js?key={{ $googleMapsApiKey }}&callback=initMap" async defer></script>
@endif
@endpush
@endsection
