@extends('layouts.admin')
@section('title', 'Plans')
@section('header', 'Billing Plans')

@section('content')
<div class="flex justify-end mb-4">
    <button onclick="document.getElementById('createModal').classList.remove('hidden')" class="px-4 py-2 bg-blue-700 text-white rounded-lg text-sm hover:bg-blue-800">+ Add Plan</button>
</div>

<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    @foreach($plans as $plan)
    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <div class="flex justify-between items-start mb-2">
            <h3 class="font-semibold">{{ $plan->name }}</h3>
            <span class="text-xs px-2 py-1 rounded-full {{ $plan->is_active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500' }}">{{ $plan->is_active ? 'Active' : 'Inactive' }}</span>
        </div>
        <div class="text-2xl font-bold text-blue-700 mb-1">₱{{ number_format($plan->monthly_rate, 2) }}<span class="text-sm font-normal text-slate-400">/mo</span></div>
        <div class="text-sm text-slate-500 mb-3">{{ $plan->speed_down }}↓ / {{ $plan->speed_up }}↑</div>
        <div class="text-xs text-slate-400 mb-3">{{ $plan->clients_count }} client(s) · MikroTik profile: {{ $plan->mikrotik_profile_name ?? '—' }}</div>
        <div class="flex gap-2">
            <button onclick="document.getElementById('editModal{{ $plan->id }}').classList.remove('hidden')" class="text-sm text-blue-600 hover:underline">Edit</button>
            <form method="POST" action="{{ route('admin.plans.destroy', $plan) }}" onsubmit="return confirm('Delete this plan?')">
                @csrf @method('DELETE')
                <button class="text-sm text-red-600 hover:underline">Delete</button>
            </form>
        </div>
    </div>

    <div id="editModal{{ $plan->id }}" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl p-6 w-full max-w-md">
            <h3 class="font-semibold mb-4">Edit {{ $plan->name }}</h3>
            <form method="POST" action="{{ route('admin.plans.update', $plan) }}" class="space-y-3">
                @csrf @method('PUT')
                <input type="text" name="name" value="{{ $plan->name }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Plan name">
                <input type="number" step="0.01" name="monthly_rate" value="{{ $plan->monthly_rate }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Monthly rate">
                <div class="grid grid-cols-2 gap-2">
                    <input type="text" name="speed_down" value="{{ $plan->speed_down }}" class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="Download speed">
                    <input type="text" name="speed_up" value="{{ $plan->speed_up }}" class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="Upload speed">
                </div>
                <input type="text" name="mikrotik_profile_name" value="{{ $plan->mikrotik_profile_name }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="MikroTik PPP profile name">
                <label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" @checked($plan->is_active)> Active</label>
                <div class="flex gap-2 pt-2">
                    <button type="submit" class="flex-1 px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Save</button>
                    <button type="button" onclick="document.getElementById('editModal{{ $plan->id }}').classList.add('hidden')" class="px-4 py-2 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</button>
                </div>
            </form>
        </div>
    </div>
    @endforeach
</div>

<div id="createModal" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 w-full max-w-md">
        <h3 class="font-semibold mb-4">New Plan</h3>
        <form method="POST" action="{{ route('admin.plans.store') }}" class="space-y-3">
            @csrf
            <input type="text" name="name" required class="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Plan name (e.g. Home 50Mbps)">
            <input type="number" step="0.01" name="monthly_rate" required class="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Monthly rate">
            <div class="grid grid-cols-2 gap-2">
                <input type="text" name="speed_down" class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="Download (e.g. 50M)">
                <input type="text" name="speed_up" class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="Upload (e.g. 10M)">
            </div>
            <input type="text" name="mikrotik_profile_name" class="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="MikroTik PPP profile name">
            <div class="flex gap-2 pt-2">
                <button type="submit" class="flex-1 px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Create</button>
                <button type="button" onclick="document.getElementById('createModal').classList.add('hidden')" class="px-4 py-2 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
