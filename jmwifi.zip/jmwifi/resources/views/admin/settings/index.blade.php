@extends('layouts.admin')
@section('title', 'Settings')
@section('header', 'Settings')

@section('content')
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <div class="bg-white rounded-xl border border-slate-200 p-6">
        <h3 class="font-semibold mb-4">System Settings</h3>
        <form method="POST" action="{{ route('admin.settings.update') }}" class="space-y-3">
            @csrf
            <div>
                <label class="block text-sm font-medium mb-1">Company Name</label>
                <input type="text" name="company_name" value="{{ $settings['company_name'] }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Support Contact</label>
                <input type="text" name="support_contact" value="{{ $settings['support_contact'] }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Billing Cycle (days)</label>
                <input type="number" name="billing_cycle_days" value="{{ $settings['billing_cycle_days'] }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Expiry Warning (days before)</label>
                <input type="number" name="expiry_warning_days" value="{{ $settings['expiry_warning_days'] }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <button type="submit" class="px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Save Settings</button>
        </form>
    </div>

    <div class="bg-white rounded-xl border border-slate-200 p-6">
        <h3 class="font-semibold mb-4">Admin & Staff Accounts</h3>
        <div class="space-y-2 mb-4">
            @foreach($staffUsers as $user)
            <div class="flex justify-between items-center text-sm py-2 border-b border-slate-50 last:border-0">
                <div>
                    <div class="font-medium">{{ $user->name }}</div>
                    <div class="text-xs text-slate-400">{{ $user->email }} · {{ ucfirst($user->role) }}</div>
                </div>
                <form method="POST" action="{{ route('admin.settings.users.toggle', $user) }}">
                    @csrf
                    <button class="text-xs px-2 py-1 rounded-full {{ $user->is_active ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500' }}">
                        {{ $user->is_active ? 'Active' : 'Inactive' }}
                    </button>
                </form>
            </div>
            @endforeach
        </div>

        <h4 class="text-sm font-semibold mb-2 pt-3 border-t border-slate-100">Add New User</h4>
        <form method="POST" action="{{ route('admin.settings.users.store') }}" class="space-y-2">
            @csrf
            <input type="text" name="name" placeholder="Full name" required class="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm">
            <input type="email" name="email" placeholder="Email" required class="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm">
            <input type="password" name="password" placeholder="Password" required class="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm">
            <select name="role" required class="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm">
                <option value="staff">Staff</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit" class="w-full px-4 py-2 bg-slate-800 text-white rounded-lg text-sm hover:bg-slate-900">Create User</button>
        </form>
    </div>
</div>
@endsection
