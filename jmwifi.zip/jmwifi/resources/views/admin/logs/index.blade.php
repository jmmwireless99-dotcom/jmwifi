@extends('layouts.admin')
@section('title', 'MikroTik Logs')
@section('header', 'MikroTik Action Logs')

@section('content')
<form method="GET" class="flex gap-2 mb-4">
    <select name="status" class="px-3 py-2 border border-slate-300 rounded-lg text-sm">
        <option value="">All Status</option>
        <option value="success" @selected(request('status')=='success')>Success</option>
        <option value="failed" @selected(request('status')=='failed')>Failed</option>
    </select>
    <button class="px-4 py-2 bg-slate-200 rounded-lg text-sm hover:bg-slate-300">Filter</button>
</form>

<div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-slate-50">
            <tr class="text-left text-slate-500">
                <th class="px-4 py-3">Action</th>
                <th class="px-4 py-3">Router</th>
                <th class="px-4 py-3">Client</th>
                <th class="px-4 py-3">Status</th>
                <th class="px-4 py-3">Message</th>
                <th class="px-4 py-3">Date</th>
            </tr>
        </thead>
        <tbody>
            @forelse($logs as $log)
            <tr class="border-t border-slate-100">
                <td class="px-4 py-3">{{ str_replace('_',' ', $log->action) }}</td>
                <td class="px-4 py-3">{{ $log->router->name ?? '—' }}</td>
                <td class="px-4 py-3">{{ $log->client->full_name ?? '—' }}</td>
                <td class="px-4 py-3">
                    <span class="text-xs px-2 py-1 rounded-full {{ $log->status === 'success' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' }}">{{ $log->status }}</span>
                </td>
                <td class="px-4 py-3 text-slate-500 max-w-sm truncate">{{ $log->message }}</td>
                <td class="px-4 py-3 text-slate-400">{{ $log->created_at->format('M d, Y h:i A') }}</td>
            </tr>
            @empty
            <tr><td colspan="6" class="px-4 py-8 text-center text-slate-400">No logs yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $logs->links() }}</div>
@endsection
