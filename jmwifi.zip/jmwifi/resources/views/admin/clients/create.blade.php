@extends('layouts.admin')
@section('title', 'Add Client')
@section('header', 'Add New Client')

@section('content')
<form method="POST" action="{{ route('admin.clients.store') }}" class="bg-white rounded-xl border border-slate-200 p-6 max-w-3xl space-y-6">
    @csrf

    <div>
        <h3 class="font-semibold mb-3 text-slate-700">Profile</h3>
        <div class="grid grid-cols-2 gap-4">
            <div class="col-span-2">
                <label class="block text-sm font-medium mb-1">Full Name *</label>
                <input type="text" name="full_name" value="{{ old('full_name') }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div class="col-span-2">
                <label class="block text-sm font-medium mb-1">Address</label>
                <input type="text" name="address" value="{{ old('address') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Contact Number</label>
                <input type="text" name="contact_number" value="{{ old('contact_number') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Email</label>
                <input type="email" name="email" value="{{ old('email') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Account Number (leave blank to auto-generate)</label>
                <input type="text" name="account_number" value="{{ old('account_number') }}" placeholder="JM-00001" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Portal Password *</label>
                <input type="password" name="password" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
        </div>
    </div>

    <div>
        <h3 class="font-semibold mb-3 text-slate-700">Plan & Billing</h3>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Plan</label>
                <select name="plan_id" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="">— None —</option>
                    @foreach($plans as $plan)
                    <option value="{{ $plan->id }}" @selected(old('plan_id') == $plan->id)>{{ $plan->name }} (₱{{ number_format($plan->monthly_rate,2) }})</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Monthly Rate Override</label>
                <input type="number" step="0.01" name="monthly_rate_override" value="{{ old('monthly_rate_override') }}" placeholder="Leave blank to use plan rate" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Due Date</label>
                <input type="date" name="due_date" value="{{ old('due_date') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Expiration Date</label>
                <input type="date" name="expiration_date" value="{{ old('expiration_date') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
        </div>
    </div>

    <div>
        <h3 class="font-semibold mb-3 text-slate-700">MikroTik Connection</h3>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Router</label>
                <select name="router_id" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="">— None —</option>
                    @foreach($routers as $router)
                    <option value="{{ $router->id }}" @selected(old('router_id') == $router->id)>{{ $router->name }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Connection Type *</label>
                <select name="connection_type" id="connection_type" class="w-full px-3 py-2 border border-slate-300 rounded-lg" onchange="toggleConnFields()">
                    <option value="pppoe" @selected(old('connection_type','pppoe')=='pppoe')>PPPoE</option>
                    <option value="ipoe" @selected(old('connection_type')=='ipoe')>IPoE / DHCP</option>
                </select>
            </div>
            <div id="pppoe_fields">
                <label class="block text-sm font-medium mb-1">PPPoE Username</label>
                <input type="text" name="pppoe_username" value="{{ old('pppoe_username') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div id="pppoe_fields2">
                <label class="block text-sm font-medium mb-1">PPPoE Password</label>
                <input type="text" name="pppoe_password" value="{{ old('pppoe_password') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div id="ipoe_fields" class="hidden">
                <label class="block text-sm font-medium mb-1">MAC Address</label>
                <input type="text" name="mac_address" value="{{ old('mac_address') }}" placeholder="AA:BB:CC:DD:EE:FF" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div id="ipoe_fields2" class="hidden">
                <label class="block text-sm font-medium mb-1">IP Address</label>
                <input type="text" name="ip_address" value="{{ old('ip_address') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
        </div>
    </div>

    <div>
        <h3 class="font-semibold mb-3 text-slate-700">Map Location (optional)</h3>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Latitude</label>
                <input type="text" name="latitude" value="{{ old('latitude') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Longitude</label>
                <input type="text" name="longitude" value="{{ old('longitude') }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
        </div>
        <p class="text-xs text-slate-400 mt-1">Tip: use the Map page to drop a pin precisely instead of typing coordinates.</p>
    </div>

    <div class="flex gap-3">
        <button type="submit" class="px-5 py-2.5 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Create Client</button>
        <a href="{{ route('admin.clients.index') }}" class="px-5 py-2.5 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</a>
    </div>
</form>

<script>
function toggleConnFields() {
    const type = document.getElementById('connection_type').value;
    document.getElementById('pppoe_fields').classList.toggle('hidden', type !== 'pppoe');
    document.getElementById('pppoe_fields2').classList.toggle('hidden', type !== 'pppoe');
    document.getElementById('ipoe_fields').classList.toggle('hidden', type !== 'ipoe');
    document.getElementById('ipoe_fields2').classList.toggle('hidden', type !== 'ipoe');
}
toggleConnFields();
</script>
@endsection
