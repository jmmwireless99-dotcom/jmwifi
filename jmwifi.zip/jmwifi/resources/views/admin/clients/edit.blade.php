@extends('layouts.admin')
@section('title', 'Edit Client')
@section('header', 'Edit Client: ' . $client->full_name)

@section('content')
<form method="POST" action="{{ route('admin.clients.update', $client) }}" class="bg-white rounded-xl border border-slate-200 p-6 max-w-3xl space-y-6">
    @csrf
    @method('PUT')

    <div>
        <h3 class="font-semibold mb-3 text-slate-700">Profile</h3>
        <div class="grid grid-cols-2 gap-4">
            <div class="col-span-2">
                <label class="block text-sm font-medium mb-1">Full Name *</label>
                <input type="text" name="full_name" value="{{ old('full_name', $client->full_name) }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div class="col-span-2">
                <label class="block text-sm font-medium mb-1">Address</label>
                <input type="text" name="address" value="{{ old('address', $client->address) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Contact Number</label>
                <input type="text" name="contact_number" value="{{ old('contact_number', $client->contact_number) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Email</label>
                <input type="email" name="email" value="{{ old('email', $client->email) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Account Number</label>
                <input type="text" name="account_number" value="{{ old('account_number', $client->account_number) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">New Password (leave blank to keep current)</label>
                <input type="password" name="password" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
        </div>
    </div>

    <div>
        <h3 class="font-semibold mb-3 text-slate-700">Plan & Billing</h3>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Plan</label>
                <select name="plan_id" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="">— None —</option>
                    @foreach($plans as $plan)
                    <option value="{{ $plan->id }}" @selected(old('plan_id', $client->plan_id) == $plan->id)>{{ $plan->name }} (₱{{ number_format($plan->monthly_rate,2) }})</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Monthly Rate Override</label>
                <input type="number" step="0.01" name="monthly_rate_override" value="{{ old('monthly_rate_override', $client->monthly_rate_override) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Due Date</label>
                <input type="date" name="due_date" value="{{ old('due_date', $client->due_date?->format('Y-m-d')) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Expiration Date</label>
                <input type="date" name="expiration_date" value="{{ old('expiration_date', $client->expiration_date?->format('Y-m-d')) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Billing Status</label>
                <select name="billing_status" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    @foreach(['active','expired','suspended','pending'] as $s)
                    <option value="{{ $s }}" @selected(old('billing_status', $client->billing_status) == $s)>{{ ucfirst($s) }}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>

    <div>
        <h3 class="font-semibold mb-3 text-slate-700">MikroTik Connection</h3>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Router</label>
                <select name="router_id" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="">— None —</option>
                    @foreach($routers as $router)
                    <option value="{{ $router->id }}" @selected(old('router_id', $client->router_id) == $router->id)>{{ $router->name }}</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Connection Type *</label>
                <select name="connection_type" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="pppoe" @selected(old('connection_type', $client->connection_type)=='pppoe')>PPPoE</option>
                    <option value="ipoe" @selected(old('connection_type', $client->connection_type)=='ipoe')>IPoE / DHCP</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">PPPoE Username</label>
                <input type="text" name="pppoe_username" value="{{ old('pppoe_username', $client->pppoe_username) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">PPPoE Password</label>
                <input type="text" name="pppoe_password" value="{{ old('pppoe_password', $client->pppoe_password) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">MAC Address</label>
                <input type="text" name="mac_address" value="{{ old('mac_address', $client->mac_address) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">IP Address</label>
                <input type="text" name="ip_address" value="{{ old('ip_address', $client->ip_address) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
        </div>
    </div>

    <div>
        <h3 class="font-semibold mb-3 text-slate-700">Map Location</h3>
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Latitude</label>
                <input type="text" name="latitude" value="{{ old('latitude', $client->primaryLocation?->latitude) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Longitude</label>
                <input type="text" name="longitude" value="{{ old('longitude', $client->primaryLocation?->longitude) }}" class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
        </div>
    </div>

    <div class="flex gap-3">
        <button type="submit" class="px-5 py-2.5 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Save Changes</button>
        <a href="{{ route('admin.clients.show', $client) }}" class="px-5 py-2.5 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</a>
    </div>
</form>
@endsection
