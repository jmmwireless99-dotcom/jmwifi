@extends('layouts.admin')
@section('title', 'Clients')
@section('header', 'Clients')

@section('content')
<div class="flex justify-between items-center mb-4">
    <form method="GET" class="flex gap-2">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search name, account #, PPPoE..."
               class="px-3 py-2 border border-slate-300 rounded-lg text-sm w-64">
        <select name="billing_status" class="px-3 py-2 border border-slate-300 rounded-lg text-sm">
            <option value="">All Billing Status</option>
            @foreach(['active','expired','suspended','pending'] as $s)
            <option value="{{ $s }}" @selected(request('billing_status') == $s)>{{ ucfirst($s) }}</option>
            @endforeach
        </select>
        <select name="connection_status" class="px-3 py-2 border border-slate-300 rounded-lg text-sm">
            <option value="">All Connection Status</option>
            @foreach(['online','offline','router_offline','unknown'] as $s)
            <option value="{{ $s }}" @selected(request('connection_status') == $s)>{{ ucfirst(str_replace('_',' ',$s)) }}</option>
            @endforeach
        </select>
        <button class="px-4 py-2 bg-slate-200 rounded-lg text-sm hover:bg-slate-300">Filter</button>
    </form>
    <a href="{{ route('admin.clients.create') }}" class="px-4 py-2 bg-blue-700 text-white rounded-lg text-sm hover:bg-blue-800">+ Add Client</a>
</div>

<div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-slate-50">
            <tr class="text-left text-slate-500">
                <th class="px-4 py-3">Account #</th>
                <th class="px-4 py-3">Name</th>
                <th class="px-4 py-3">Plan</th>
                <th class="px-4 py-3">Billing</th>
                <th class="px-4 py-3">Connection</th>
                <th class="px-4 py-3">Expiration</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            @forelse($clients as $client)
            <tr class="border-t border-slate-100 hover:bg-slate-50">
                <td class="px-4 py-3 font-mono text-xs">{{ $client->account_number }}</td>
                <td class="px-4 py-3 font-medium">{{ $client->full_name }}</td>
                <td class="px-4 py-3">{{ $client->plan->name ?? '—' }}</td>
                <td class="px-4 py-3">
                    <span class="text-xs px-2 py-1 rounded-full
                        {{ $client->billing_status === 'active' ? 'bg-emerald-100 text-emerald-700' : '' }}
                        {{ $client->billing_status === 'expired' ? 'bg-red-100 text-red-700' : '' }}
                        {{ $client->billing_status === 'suspended' ? 'bg-amber-100 text-amber-700' : '' }}
                        {{ $client->billing_status === 'pending' ? 'bg-slate-100 text-slate-700' : '' }}">
                        {{ ucfirst($client->billing_status) }}
                    </span>
                </td>
                <td class="px-4 py-3">
                    <span class="text-xs px-2 py-1 rounded-full
                        {{ $client->connection_status === 'online' ? 'bg-blue-100 text-blue-700' : '' }}
                        {{ $client->connection_status === 'offline' ? 'bg-slate-100 text-slate-700' : '' }}
                        {{ $client->connection_status === 'router_offline' ? 'bg-amber-100 text-amber-700' : '' }}
                        {{ $client->connection_status === 'unknown' ? 'bg-slate-100 text-slate-400' : '' }}">
                        {{ ucfirst(str_replace('_',' ',$client->connection_status)) }}
                    </span>
                </td>
                <td class="px-4 py-3">{{ $client->expiration_date?->format('M d, Y') ?? '—' }}</td>
                <td class="px-4 py-3 text-right">
                    <a href="{{ route('admin.clients.show', $client) }}" class="text-blue-600 hover:underline">View</a>
                </td>
            </tr>
            @empty
            <tr><td colspan="7" class="px-4 py-8 text-center text-slate-400">No clients found.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-4">{{ $clients->links() }}</div>
@endsection
