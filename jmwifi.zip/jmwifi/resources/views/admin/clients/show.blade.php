@extends('layouts.admin')
@section('title', $client->full_name)
@section('header', $client->full_name)

@section('content')
<div class="flex justify-between items-start mb-4">
    <div class="flex gap-2">
        <span class="text-xs px-3 py-1.5 rounded-full font-medium
            {{ $client->billing_status === 'active' ? 'bg-emerald-100 text-emerald-700' : '' }}
            {{ $client->billing_status === 'expired' ? 'bg-red-100 text-red-700' : '' }}
            {{ $client->billing_status === 'suspended' ? 'bg-amber-100 text-amber-700' : '' }}
            {{ $client->billing_status === 'pending' ? 'bg-slate-100 text-slate-700' : '' }}">
            {{ ucfirst($client->billing_status) }}
        </span>
        <span class="text-xs px-3 py-1.5 rounded-full font-medium
            {{ $client->connection_status === 'online' ? 'bg-blue-100 text-blue-700' : '' }}
            {{ $client->connection_status === 'offline' ? 'bg-slate-100 text-slate-700' : '' }}
            {{ $client->connection_status === 'router_offline' ? 'bg-amber-100 text-amber-700' : '' }}
            {{ $client->connection_status === 'unknown' ? 'bg-slate-100 text-slate-400' : '' }}">
            {{ ucfirst(str_replace('_',' ',$client->connection_status)) }}
        </span>
    </div>
    <div class="flex gap-2">
        <form method="POST" action="{{ route('admin.clients.refresh-status', $client) }}">
            @csrf
            <button class="px-3 py-2 bg-slate-100 rounded-lg text-sm hover:bg-slate-200">🔄 Refresh Status</button>
        </form>
        <form method="POST" action="{{ route('admin.clients.toggle-suspend', $client) }}">
            @csrf
            <button class="px-3 py-2 {{ $client->billing_status === 'expired' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' }} rounded-lg text-sm hover:opacity-80">
                {{ $client->billing_status === 'expired' ? '✅ Restore / Reconnect' : '⛔ Suspend' }}
            </button>
        </form>
        <a href="{{ route('admin.clients.edit', $client) }}" class="px-3 py-2 bg-blue-700 text-white rounded-lg text-sm hover:bg-blue-800">Edit</a>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
    <div class="lg:col-span-1 space-y-6">
        <div class="bg-white rounded-xl border border-slate-200 p-5">
            <h3 class="font-semibold mb-3">Profile</h3>
            <dl class="text-sm space-y-2">
                <div class="flex justify-between"><dt class="text-slate-400">Account #</dt><dd class="font-mono">{{ $client->account_number }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Address</dt><dd class="text-right">{{ $client->address ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Contact</dt><dd>{{ $client->contact_number ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Email</dt><dd>{{ $client->email ?? '—' }}</dd></div>
            </dl>
        </div>

        <div class="bg-white rounded-xl border border-slate-200 p-5">
            <h3 class="font-semibold mb-3">Billing</h3>
            <dl class="text-sm space-y-2">
                <div class="flex justify-between"><dt class="text-slate-400">Plan</dt><dd>{{ $client->plan->name ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Monthly Rate</dt><dd>₱{{ number_format($client->monthly_rate, 2) }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Due Date</dt><dd>{{ $client->due_date?->format('M d, Y') ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Expiration</dt><dd>{{ $client->expiration_date?->format('M d, Y') ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Last Payment</dt><dd>{{ $client->last_payment_date?->format('M d, Y') ?? '—' }}</dd></div>
            </dl>
        </div>

        <div class="bg-white rounded-xl border border-slate-200 p-5">
            <h3 class="font-semibold mb-3">MikroTik</h3>
            <dl class="text-sm space-y-2">
                <div class="flex justify-between"><dt class="text-slate-400">Router</dt><dd>{{ $client->router->name ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">Type</dt><dd>{{ strtoupper($client->connection_type) }}</dd></div>
                @if($client->connection_type === 'pppoe')
                <div class="flex justify-between"><dt class="text-slate-400">PPPoE User</dt><dd class="font-mono">{{ $client->pppoe_username ?? '—' }}</dd></div>
                @else
                <div class="flex justify-between"><dt class="text-slate-400">MAC</dt><dd class="font-mono">{{ $client->mac_address ?? '—' }}</dd></div>
                <div class="flex justify-between"><dt class="text-slate-400">IP</dt><dd class="font-mono">{{ $client->ip_address ?? '—' }}</dd></div>
                @endif
                <div class="flex justify-between"><dt class="text-slate-400">Last Synced</dt><dd>{{ $client->last_synced_at?->diffForHumans() ?? 'Never' }}</dd></div>
            </dl>
        </div>
    </div>

    <div class="lg:col-span-2 space-y-6">
        <div class="bg-white rounded-xl border border-slate-200 p-5">
            <h3 class="font-semibold mb-3">Recent Payments</h3>
            <table class="w-full text-sm">
                <thead><tr class="text-left text-slate-400 border-b border-slate-100"><th class="py-2">Reference</th><th class="py-2">Amount</th><th class="py-2">Method</th><th class="py-2">Status</th><th class="py-2">Date</th></tr></thead>
                <tbody>
                @forelse($client->payments as $payment)
                <tr class="border-b border-slate-50">
                    <td class="py-2"><a href="{{ route('admin.payments.show', $payment) }}" class="text-blue-600 hover:underline">{{ $payment->payment_reference }}</a></td>
                    <td class="py-2">₱{{ number_format($payment->amount, 2) }}</td>
                    <td class="py-2 capitalize">{{ str_replace('_',' ',$payment->method) }}</td>
                    <td class="py-2 capitalize">{{ $payment->status }}</td>
                    <td class="py-2">{{ $payment->created_at->format('M d, Y') }}</td>
                </tr>
                @empty
                <tr><td colspan="5" class="py-4 text-center text-slate-400">No payments yet.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>

        <div class="bg-white rounded-xl border border-slate-200 p-5">
            <h3 class="font-semibold mb-3">MikroTik Action Log</h3>
            <div class="space-y-2 text-sm max-h-80 overflow-y-auto">
                @forelse($client->mikrotikLogs as $log)
                <div class="flex justify-between items-start py-2 border-b border-slate-50">
                    <div>
                        <div class="font-medium">{{ str_replace('_',' ',$log->action) }}</div>
                        <div class="text-xs text-slate-400">{{ $log->message }}</div>
                    </div>
                    <div class="text-right">
                        <span class="text-xs px-2 py-0.5 rounded-full {{ $log->status === 'success' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' }}">{{ $log->status }}</span>
                        <div class="text-xs text-slate-400 mt-1">{{ $log->created_at->diffForHumans() }}</div>
                    </div>
                </div>
                @empty
                <div class="text-slate-400">No MikroTik actions logged yet.</div>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
