@extends('layouts.admin')
@section('title', $invoice->invoice_number)
@section('header', 'Invoice ' . $invoice->invoice_number)

@section('content')
<div class="bg-white rounded-xl border border-slate-200 p-6 max-w-2xl">
    <dl class="text-sm space-y-3 mb-6">
        <div class="flex justify-between"><dt class="text-slate-400">Client</dt><dd><a href="{{ route('admin.clients.show', $invoice->client) }}" class="text-blue-600 hover:underline">{{ $invoice->client->full_name }}</a></dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Amount</dt><dd>₱{{ number_format($invoice->amount, 2) }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Amount Paid</dt><dd>₱{{ number_format($invoice->amount_paid, 2) }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Balance</dt><dd>₱{{ number_format($invoice->balance, 2) }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Due Date</dt><dd>{{ $invoice->due_date->format('M d, Y') }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Status</dt><dd class="capitalize">{{ $invoice->status }}</dd></div>
    </dl>

    <h3 class="font-semibold mb-3">Payments Applied</h3>
    <table class="w-full text-sm">
        <thead><tr class="text-left text-slate-400 border-b border-slate-100"><th class="py-2">Reference</th><th class="py-2">Amount</th><th class="py-2">Date</th></tr></thead>
        <tbody>
        @forelse($invoice->payments as $payment)
        <tr class="border-b border-slate-50">
            <td class="py-2"><a href="{{ route('admin.payments.show', $payment) }}" class="text-blue-600 hover:underline">{{ $payment->payment_reference }}</a></td>
            <td class="py-2">₱{{ number_format($payment->amount, 2) }}</td>
            <td class="py-2">{{ $payment->paid_at?->format('M d, Y') }}</td>
        </tr>
        @empty
        <tr><td colspan="3" class="py-4 text-center text-slate-400">No payments applied yet.</td></tr>
        @endforelse
        </tbody>
    </table>
</div>
@endsection
