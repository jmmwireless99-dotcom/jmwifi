@extends('layouts.admin')
@section('title', 'Invoices')
@section('header', 'Invoices')

@section('content')
<div class="flex justify-between items-center mb-4">
    <form method="GET" class="flex gap-2">
        <select name="status" class="px-3 py-2 border border-slate-300 rounded-lg text-sm">
            <option value="">All Status</option>
            @foreach(['unpaid','paid','partial','void'] as $s)
            <option value="{{ $s }}" @selected(request('status')==$s)>{{ ucfirst($s) }}</option>
            @endforeach
        </select>
        <button class="px-4 py-2 bg-slate-200 rounded-lg text-sm hover:bg-slate-300">Filter</button>
    </form>
    <button onclick="document.getElementById('createModal').classList.remove('hidden')" class="px-4 py-2 bg-blue-700 text-white rounded-lg text-sm hover:bg-blue-800">+ New Invoice</button>
</div>

<div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-slate-50">
            <tr class="text-left text-slate-500">
                <th class="px-4 py-3">Invoice #</th>
                <th class="px-4 py-3">Client</th>
                <th class="px-4 py-3">Amount</th>
                <th class="px-4 py-3">Due Date</th>
                <th class="px-4 py-3">Status</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            @forelse($invoices as $invoice)
            <tr class="border-t border-slate-100 hover:bg-slate-50">
                <td class="px-4 py-3 font-mono text-xs">{{ $invoice->invoice_number }}</td>
                <td class="px-4 py-3">{{ $invoice->client->full_name ?? 'N/A' }}</td>
                <td class="px-4 py-3">₱{{ number_format($invoice->amount, 2) }}</td>
                <td class="px-4 py-3">{{ $invoice->due_date->format('M d, Y') }}</td>
                <td class="px-4 py-3">
                    <span class="text-xs px-2 py-1 rounded-full
                        {{ $invoice->status === 'paid' ? 'bg-emerald-100 text-emerald-700' : '' }}
                        {{ $invoice->status === 'unpaid' ? 'bg-amber-100 text-amber-700' : '' }}
                        {{ $invoice->status === 'partial' ? 'bg-blue-100 text-blue-700' : '' }}">
                        {{ ucfirst($invoice->status) }}
                    </span>
                </td>
                <td class="px-4 py-3 text-right"><a href="{{ route('admin.invoices.show', $invoice) }}" class="text-blue-600 hover:underline">View</a></td>
            </tr>
            @empty
            <tr><td colspan="6" class="px-4 py-8 text-center text-slate-400">No invoices yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $invoices->links() }}</div>

<div id="createModal" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 w-full max-w-md">
        <h3 class="font-semibold mb-4">New Invoice</h3>
        <form method="POST" action="{{ route('admin.invoices.store') }}" class="space-y-3">
            @csrf
            <div>
                <label class="block text-sm font-medium mb-1">Client</label>
                <select name="client_id" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="">Select client...</option>
                    @foreach(\App\Models\Client::orderBy('full_name')->get() as $c)
                    <option value="{{ $c->id }}">{{ $c->full_name }} ({{ $c->account_number }})</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Amount</label>
                <input type="number" step="0.01" name="amount" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Due Date</label>
                <input type="date" name="due_date" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div class="flex gap-2 pt-2">
                <button type="submit" class="flex-1 px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Create</button>
                <button type="button" onclick="document.getElementById('createModal').classList.add('hidden')" class="px-4 py-2 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
