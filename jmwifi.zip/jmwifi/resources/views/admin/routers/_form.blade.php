{{-- Shared by admin.routers.index for both the "Add Router" and "Edit Router" modals --}}
<input type="text" name="name" value="{{ $router->name ?? '' }}" required class="w-full px-3 py-2 border border-slate-300 rounded-lg" placeholder="Router name (e.g. Main Office MikroTik)">

<div class="grid grid-cols-2 gap-2">
    <input type="text" name="ip_address" value="{{ $router->ip_address ?? '' }}" required class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="IP address">
    <input type="number" name="api_port" value="{{ $router->api_port ?? 8728 }}" required class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="API port">
</div>

<div class="grid grid-cols-2 gap-2">
    <input type="text" name="api_username" value="{{ $router->api_username ?? '' }}" required class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="API username">
    <input type="password" name="api_password" {{ $router ? '' : 'required' }} class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="{{ $router ? 'Leave blank to keep current' : 'API password' }}">
</div>

<label class="flex items-center gap-2 text-sm"><input type="checkbox" name="use_ssl" value="1" @checked($router->use_ssl ?? false)> Use SSL (port 8729)</label>

<select name="client_mode" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
    <option value="pppoe" @selected(($router->client_mode ?? '')=='pppoe')>PPPoE only</option>
    <option value="ipoe" @selected(($router->client_mode ?? '')=='ipoe')>IPoE / DHCP only</option>
    <option value="both" @selected(($router->client_mode ?? 'both')=='both')>Both</option>
</select>

<div class="text-xs text-slate-400 pt-2">RouterOS profile / list names this app manages:</div>
<div class="grid grid-cols-1 gap-2">
    <input type="text" name="normal_pppoe_profile" value="{{ $router->normal_pppoe_profile ?? 'default' }}" required class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="Normal PPPoE profile name">
    <input type="text" name="expired_pppoe_profile" value="{{ $router->expired_pppoe_profile ?? 'EXPIRED' }}" required class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="Expired PPPoE profile name">
    <input type="text" name="expired_address_list" value="{{ $router->expired_address_list ?? 'EXPIRED-CLIENTS' }}" required class="px-3 py-2 border border-slate-300 rounded-lg" placeholder="Expired IPoE address-list name">
</div>

<label class="flex items-center gap-2 text-sm"><input type="checkbox" name="is_active" value="1" @checked($router->is_active ?? true)> Active</label>
