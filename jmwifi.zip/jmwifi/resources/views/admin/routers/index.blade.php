@extends('layouts.admin')
@section('title', 'Routers')
@section('header', 'MikroTik Routers')

@section('content')
<div class="flex justify-end mb-4">
    <button onclick="document.getElementById('createModal').classList.remove('hidden')" class="px-4 py-2 bg-blue-700 text-white rounded-lg text-sm hover:bg-blue-800">+ Add Router</button>
</div>

<div class="space-y-4">
    @forelse($routers as $router)
    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <div class="flex justify-between items-start">
            <div>
                <div class="flex items-center gap-2 mb-1">
                    <h3 class="font-semibold">{{ $router->name }}</h3>
                    <span class="text-xs px-2 py-1 rounded-full {{ $router->status === 'online' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' }}">{{ ucfirst($router->status) }}</span>
                </div>
                <div class="text-sm text-slate-500">{{ $router->ip_address }}:{{ $router->use_ssl ? 8729 : $router->api_port }} · {{ strtoupper($router->client_mode) }} · {{ $router->clients_count }} client(s)</div>
                @if($router->last_error)
                <div class="text-xs text-red-500 mt-1">{{ $router->last_error }}</div>
                @endif
                <div class="text-xs text-slate-400 mt-1">Last checked: {{ $router->last_checked_at?->diffForHumans() ?? 'Never' }}</div>
            </div>
            <div class="flex gap-2">
                <form method="POST" action="{{ route('admin.routers.test-connection', $router) }}">
                    @csrf
                    <button class="px-3 py-1.5 bg-slate-100 rounded-lg text-sm hover:bg-slate-200">Test Connection</button>
                </form>
                <form method="POST" action="{{ route('admin.routers.sync-now', $router) }}">
                    @csrf
                    <button class="px-3 py-1.5 bg-blue-100 text-blue-700 rounded-lg text-sm hover:bg-blue-200">Sync Now</button>
                </form>
                <button onclick="document.getElementById('editModal{{ $router->id }}').classList.remove('hidden')" class="px-3 py-1.5 bg-slate-100 rounded-lg text-sm hover:bg-slate-200">Edit</button>
            </div>
        </div>
    </div>

    <div id="editModal{{ $router->id }}" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <h3 class="font-semibold mb-4">Edit {{ $router->name }}</h3>
            <form method="POST" action="{{ route('admin.routers.update', $router) }}" class="space-y-3">
                @csrf @method('PUT')
                @include('admin.routers._form', ['router' => $router])
                <div class="flex gap-2 pt-2">
                    <button type="submit" class="flex-1 px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Save</button>
                    <button type="button" onclick="document.getElementById('editModal{{ $router->id }}').classList.add('hidden')" class="px-4 py-2 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</button>
                </div>
            </form>
            <form method="POST" action="{{ route('admin.routers.destroy', $router) }}" onsubmit="return confirm('Delete this router?')" class="mt-2">
                @csrf @method('DELETE')
                <button class="text-sm text-red-600 hover:underline">Delete Router</button>
            </form>
        </div>
    </div>
    @empty
    <div class="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-400">No routers configured yet. Add your MikroTik router to begin syncing clients.</div>
    @endforelse
</div>

<div id="createModal" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <h3 class="font-semibold mb-4">Add MikroTik Router</h3>
        <form method="POST" action="{{ route('admin.routers.store') }}" class="space-y-3">
            @csrf
            @include('admin.routers._form', ['router' => null])
            <div class="flex gap-2 pt-2">
                <button type="submit" class="flex-1 px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Add Router</button>
                <button type="button" onclick="document.getElementById('createModal').classList.add('hidden')" class="px-4 py-2 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
