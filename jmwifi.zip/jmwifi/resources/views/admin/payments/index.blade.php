@extends('layouts.admin')
@section('title', 'Payments')
@section('header', 'Payments')

@section('content')
<div class="flex justify-between items-center mb-4">
    <form method="GET" class="flex gap-2">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search reference or client..." class="px-3 py-2 border border-slate-300 rounded-lg text-sm w-64">
        <select name="status" class="px-3 py-2 border border-slate-300 rounded-lg text-sm">
            <option value="">All Status</option>
            @foreach(['pending','paid','failed','expired','refunded'] as $s)
            <option value="{{ $s }}" @selected(request('status')==$s)>{{ ucfirst($s) }}</option>
            @endforeach
        </select>
        <button class="px-4 py-2 bg-slate-200 rounded-lg text-sm hover:bg-slate-300">Filter</button>
    </form>
    <button onclick="document.getElementById('manualModal').classList.remove('hidden')" class="px-4 py-2 bg-blue-700 text-white rounded-lg text-sm hover:bg-blue-800">+ Record Manual Payment</button>
</div>

<div class="bg-white rounded-xl border border-slate-200 overflow-hidden">
    <table class="w-full text-sm">
        <thead class="bg-slate-50">
            <tr class="text-left text-slate-500">
                <th class="px-4 py-3">Reference</th>
                <th class="px-4 py-3">Client</th>
                <th class="px-4 py-3">Amount</th>
                <th class="px-4 py-3">Method</th>
                <th class="px-4 py-3">Status</th>
                <th class="px-4 py-3">Date</th>
                <th class="px-4 py-3"></th>
            </tr>
        </thead>
        <tbody>
            @forelse($payments as $payment)
            <tr class="border-t border-slate-100 hover:bg-slate-50">
                <td class="px-4 py-3 font-mono text-xs">{{ $payment->payment_reference }}</td>
                <td class="px-4 py-3">{{ $payment->client->full_name ?? 'N/A' }}</td>
                <td class="px-4 py-3">₱{{ number_format($payment->amount, 2) }}</td>
                <td class="px-4 py-3 capitalize">{{ str_replace('_',' ',$payment->method) }}</td>
                <td class="px-4 py-3">
                    <span class="text-xs px-2 py-1 rounded-full
                        {{ $payment->status === 'paid' ? 'bg-emerald-100 text-emerald-700' : '' }}
                        {{ $payment->status === 'pending' ? 'bg-amber-100 text-amber-700' : '' }}
                        {{ $payment->status === 'failed' ? 'bg-red-100 text-red-700' : '' }}">
                        {{ ucfirst($payment->status) }}
                    </span>
                </td>
                <td class="px-4 py-3">{{ $payment->created_at->format('M d, Y') }}</td>
                <td class="px-4 py-3 text-right"><a href="{{ route('admin.payments.show', $payment) }}" class="text-blue-600 hover:underline">View</a></td>
            </tr>
            @empty
            <tr><td colspan="7" class="px-4 py-8 text-center text-slate-400">No payments found.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div class="mt-4">{{ $payments->links() }}</div>

<!-- Manual Payment Modal -->
<div id="manualModal" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 w-full max-w-md">
        <h3 class="font-semibold mb-4">Record Manual Payment</h3>
        <form method="POST" action="{{ route('admin.payments.manual') }}" class="space-y-3">
            @csrf
            <div>
                <label class="block text-sm font-medium mb-1">Client</label>
                <select name="client_id" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="">Select client...</option>
                    @foreach(\App\Models\Client::orderBy('full_name')->get() as $c)
                    <option value="{{ $c->id }}">{{ $c->full_name }} ({{ $c->account_number }})</option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Amount</label>
                <input type="number" step="0.01" name="amount" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Method</label>
                <select name="method" required class="w-full px-3 py-2 border border-slate-300 rounded-lg">
                    <option value="cash">Cash</option>
                    <option value="manual_gcash">Manual GCash Transfer</option>
                    <option value="other">Other</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Notes</label>
                <textarea name="notes" class="w-full px-3 py-2 border border-slate-300 rounded-lg"></textarea>
            </div>
            <div class="flex gap-2 pt-2">
                <button type="submit" class="flex-1 px-4 py-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800">Record & Reconnect</button>
                <button type="button" onclick="document.getElementById('manualModal').classList.add('hidden')" class="px-4 py-2 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
