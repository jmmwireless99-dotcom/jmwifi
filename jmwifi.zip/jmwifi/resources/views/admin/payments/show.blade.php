@extends('layouts.admin')
@section('title', 'Payment ' . $payment->payment_reference)
@section('header', 'Payment Details')

@section('content')
<div class="bg-white rounded-xl border border-slate-200 p-6 max-w-2xl">
    <div class="flex justify-between items-start mb-6">
        <div>
            <div class="text-2xl font-bold">₱{{ number_format($payment->amount, 2) }}</div>
            <div class="text-slate-400 text-sm font-mono">{{ $payment->payment_reference }}</div>
        </div>
        <span class="text-xs px-3 py-1.5 rounded-full font-medium
            {{ $payment->status === 'paid' ? 'bg-emerald-100 text-emerald-700' : '' }}
            {{ $payment->status === 'pending' ? 'bg-amber-100 text-amber-700' : '' }}
            {{ $payment->status === 'failed' ? 'bg-red-100 text-red-700' : '' }}">
            {{ ucfirst($payment->status) }}
        </span>
    </div>

    <dl class="text-sm space-y-3 mb-6">
        <div class="flex justify-between"><dt class="text-slate-400">Client</dt><dd><a href="{{ route('admin.clients.show', $payment->client) }}" class="text-blue-600 hover:underline">{{ $payment->client->full_name }}</a></dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Method</dt><dd class="capitalize">{{ str_replace('_',' ',$payment->method) }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Purpose</dt><dd class="capitalize">{{ $payment->purpose }}</dd></div>
        <div class="flex justify-between"><dt class="text-slate-400">Date Created</dt><dd>{{ $payment->created_at->format('M d, Y h:i A') }}</dd></div>
        @if($payment->paid_at)
        <div class="flex justify-between"><dt class="text-slate-400">Date Paid</dt><dd>{{ $payment->paid_at->format('M d, Y h:i A') }}</dd></div>
        @endif
        @if($payment->paymongo_checkout_id)
        <div class="flex justify-between"><dt class="text-slate-400">PayMongo Checkout ID</dt><dd class="font-mono text-xs">{{ $payment->paymongo_checkout_id }}</dd></div>
        @endif
        @if($payment->notes)
        <div class="flex justify-between"><dt class="text-slate-400">Notes</dt><dd class="text-right max-w-xs">{{ $payment->notes }}</dd></div>
        @endif
        @if($payment->verifier)
        <div class="flex justify-between"><dt class="text-slate-400">Verified By</dt><dd>{{ $payment->verifier->name }}</dd></div>
        @endif
    </dl>

    @if($payment->proof_image_path)
    <div class="mb-6">
        <div class="text-sm text-slate-400 mb-2">Proof of Payment</div>
        <img src="{{ route('admin.payments.proof-image', $payment) }}" class="rounded-lg border border-slate-200 max-w-sm" alt="Proof of payment">
    </div>
    @endif

    <div class="flex gap-2 flex-wrap">
        @if($payment->status === 'pending' && $payment->method === 'manual_gcash')
            <form method="POST" action="{{ route('admin.payments.approve-proof', $payment) }}">
                @csrf
                <button class="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm hover:bg-emerald-700">✅ Approve & Reconnect</button>
            </form>
            <button onclick="document.getElementById('rejectModal').classList.remove('hidden')" class="px-4 py-2 bg-red-100 text-red-700 rounded-lg text-sm hover:bg-red-200">Reject</button>
        @endif

        @if($payment->status === 'pending' && $payment->paymongo_checkout_id)
            <form method="POST" action="{{ route('admin.payments.verify-paymongo', $payment) }}">
                @csrf
                <button class="px-4 py-2 bg-blue-700 text-white rounded-lg text-sm hover:bg-blue-800">🔄 Verify with PayMongo</button>
            </form>
        @endif

        @if($payment->status === 'paid')
            <a href="{{ route('client.receipt', $payment) }}" target="_blank" class="px-4 py-2 bg-slate-100 rounded-lg text-sm hover:bg-slate-200">View Receipt</a>
        @endif
    </div>
</div>

<div id="rejectModal" class="hidden fixed inset-0 bg-black/40 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-6 w-full max-w-md">
        <h3 class="font-semibold mb-4">Reject Payment Proof</h3>
        <form method="POST" action="{{ route('admin.payments.reject-proof', $payment) }}" class="space-y-3">
            @csrf
            <textarea name="notes" required placeholder="Reason for rejection..." class="w-full px-3 py-2 border border-slate-300 rounded-lg"></textarea>
            <div class="flex gap-2">
                <button type="submit" class="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">Reject</button>
                <button type="button" onclick="document.getElementById('rejectModal').classList.add('hidden')" class="px-4 py-2 bg-slate-100 rounded-lg hover:bg-slate-200">Cancel</button>
            </div>
        </form>
    </div>
</div>
@endsection
