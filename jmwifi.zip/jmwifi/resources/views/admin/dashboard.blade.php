@extends('layouts.admin')
@section('title', 'Dashboard')
@section('header', 'Dashboard')

@section('content')
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
    @php
    $cards = [
        ['label' => 'Total Clients', 'value' => $stats['total_clients'], 'color' => 'bg-slate-100 text-slate-700'],
        ['label' => 'Active', 'value' => $stats['active_clients'], 'color' => 'bg-emerald-100 text-emerald-700'],
        ['label' => 'Expired', 'value' => $stats['expired_clients'], 'color' => 'bg-red-100 text-red-700'],
        ['label' => 'Online Now', 'value' => $stats['online_clients'], 'color' => 'bg-blue-100 text-blue-700'],
        ['label' => 'Offline', 'value' => $stats['offline_clients'], 'color' => 'bg-slate-100 text-slate-700'],
        ['label' => 'Router Offline', 'value' => $stats['router_offline_clients'], 'color' => 'bg-amber-100 text-amber-700'],
    ];
    @endphp
    @foreach($cards as $card)
    <div class="bg-white rounded-xl border border-slate-200 p-5">
        <div class="text-xs uppercase tracking-wide text-slate-400 mb-1">{{ $card['label'] }}</div>
        <div class="text-2xl font-bold">{{ $card['value'] }}</div>
    </div>
    @endforeach
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
    <!-- Routers -->
    <div class="bg-white rounded-xl border border-slate-200 p-5 lg:col-span-1">
        <div class="font-semibold mb-3 flex items-center justify-between">
            <span>MikroTik Routers</span>
            <span class="text-xs px-2 py-1 rounded-full {{ $routersOnline == $routersTotal && $routersTotal > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700' }}">
                {{ $routersOnline }}/{{ $routersTotal }} online
            </span>
        </div>
        <div class="space-y-2">
            @forelse($routers as $router)
            <div class="flex items-center justify-between text-sm py-2 border-b border-slate-100 last:border-0">
                <div>
                    <div class="font-medium">{{ $router->name }}</div>
                    <div class="text-xs text-slate-400">{{ $router->ip_address }}</div>
                </div>
                <span class="text-xs px-2 py-1 rounded-full {{ $router->status === 'online' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700' }}">
                    {{ ucfirst($router->status) }}
                </span>
            </div>
            @empty
            <div class="text-sm text-slate-400">No routers configured yet.</div>
            @endforelse
        </div>
    </div>

    <!-- Collection -->
    <div class="bg-white rounded-xl border border-slate-200 p-5 lg:col-span-1">
        <div class="font-semibold mb-3">This Month's Collection</div>
        <div class="text-3xl font-bold text-emerald-600">₱{{ number_format($monthlyCollection, 2) }}</div>
        <div class="mt-4 text-sm text-slate-500">Pending Payments</div>
        <div class="text-xl font-semibold text-amber-600">{{ $pendingPayments }} (₱{{ number_format($pendingPaymentsAmount, 2) }})</div>
    </div>

    <!-- VPS Resource Usage -->
    <div class="bg-white rounded-xl border border-slate-200 p-5 lg:col-span-1">
        <div class="font-semibold mb-3">VPS Resource Usage</div>
        @php($v = $vpsUsage)
        <div class="space-y-3 text-sm">
            <div>
                <div class="flex justify-between mb-1"><span>CPU Load</span><span>{{ $v['cpu_load'] ?? 'N/A' }}</span></div>
            </div>
            <div>
                <div class="flex justify-between mb-1"><span>RAM Used</span><span>{{ $v['ram_used_percent'] !== null ? $v['ram_used_percent'].'%' : 'N/A' }}</span></div>
                @if($v['ram_used_percent'] !== null)
                <div class="w-full bg-slate-100 rounded-full h-2"><div class="bg-blue-600 h-2 rounded-full" style="width: {{ $v['ram_used_percent'] }}%"></div></div>
                @endif
            </div>
            <div>
                <div class="flex justify-between mb-1"><span>Disk Used</span><span>{{ $v['disk_used_percent'] !== null ? $v['disk_used_percent'].'%' : 'N/A' }}</span></div>
                @if($v['disk_used_percent'] !== null)
                <div class="w-full bg-slate-100 rounded-full h-2"><div class="bg-purple-600 h-2 rounded-full" style="width: {{ $v['disk_used_percent'] }}%"></div></div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Recent payments -->
<div class="bg-white rounded-xl border border-slate-200 p-5">
    <div class="font-semibold mb-3">Recent Payments</div>
    <table class="w-full text-sm">
        <thead>
            <tr class="text-left text-slate-400 border-b border-slate-100">
                <th class="py-2">Reference</th>
                <th class="py-2">Client</th>
                <th class="py-2">Amount</th>
                <th class="py-2">Method</th>
                <th class="py-2">Date</th>
            </tr>
        </thead>
        <tbody>
            @forelse($recentPayments as $payment)
            <tr class="border-b border-slate-50">
                <td class="py-2"><a href="{{ route('admin.payments.show', $payment) }}" class="text-blue-600 hover:underline">{{ $payment->payment_reference }}</a></td>
                <td class="py-2">{{ $payment->client->full_name ?? 'N/A' }}</td>
                <td class="py-2">₱{{ number_format($payment->amount, 2) }}</td>
                <td class="py-2 capitalize">{{ str_replace('_', ' ', $payment->method) }}</td>
                <td class="py-2">{{ $payment->paid_at?->format('M d, Y h:i A') }}</td>
            </tr>
            @empty
            <tr><td colspan="5" class="py-4 text-center text-slate-400">No payments yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
