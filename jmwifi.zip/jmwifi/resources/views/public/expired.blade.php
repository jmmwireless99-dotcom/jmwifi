<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Expired - JM WIFI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-red-50 min-h-screen flex items-center justify-center px-4">
    <div class="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center">
        <div class="text-5xl mb-4">⚠️</div>
        <h1 class="text-xl font-bold text-red-700 mb-2">Your JM WIFI account is expired.</h1>
        <p class="text-slate-500 mb-6">Please pay your bill to reconnect.</p>

        @if($client ?? null)
            <div class="bg-slate-50 rounded-lg p-4 mb-6 text-left text-sm space-y-2">
                <div class="flex justify-between"><span class="text-slate-400">Account</span><span class="font-mono">{{ $client->account_number }}</span></div>
                <div class="flex justify-between"><span class="text-slate-400">Plan</span><span>{{ $client->plan->name ?? '—' }}</span></div>
                <div class="flex justify-between font-semibold"><span>Amount Due</span><span>₱{{ number_format($amountDue, 2) }}</span></div>
            </div>

            <form method="POST" action="{{ route('client.expired.pay') }}">
                @csrf
                <button type="submit" class="w-full px-5 py-3 bg-[#007dfe] text-white rounded-lg font-medium hover:opacity-90">
                    Pay with GCash to Reconnect
                </button>
            </form>

            @if(session('error'))
            <div class="mt-3 text-sm text-red-600">{{ session('error') }}</div>
            @endif
        @else
            <a href="{{ route('client.login') }}" class="inline-block w-full px-5 py-3 bg-blue-700 text-white rounded-lg font-medium hover:bg-blue-800">
                Log In to Pay
            </a>
        @endif

        <p class="text-xs text-slate-400 mt-6">Need help? Contact JM WIFI support.</p>
    </div>
</body>
</html>
