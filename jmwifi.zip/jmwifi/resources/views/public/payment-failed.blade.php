<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Failed - JM WIFI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-red-50 min-h-screen flex items-center justify-center px-4">
    <div class="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center">
        <div class="text-5xl mb-4">❌</div>
        <h1 class="text-xl font-bold text-red-700 mb-2">Payment Cancelled or Failed</h1>
        <p class="text-slate-500 mb-6">Your payment was not completed. No charges were made. You can try again anytime.</p>
        <a href="{{ route('client.login') }}" class="inline-block w-full px-5 py-3 bg-blue-700 text-white rounded-lg font-medium hover:bg-blue-800">Back to My Account</a>
    </div>
</body>
</html>
