<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Result - JM WIFI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-emerald-50 min-h-screen flex items-center justify-center px-4">
    <div class="bg-white rounded-2xl shadow-xl max-w-md w-full p-8 text-center">
        @if($payment && $payment->status === 'paid')
            <div class="text-5xl mb-4">✅</div>
            <h1 class="text-xl font-bold text-emerald-700 mb-2">Payment Successful!</h1>
            <p class="text-slate-500 mb-6">Your account has been reconnected. Thank you!</p>
            <div class="bg-slate-50 rounded-lg p-4 mb-6 text-left text-sm space-y-2">
                <div class="flex justify-between"><span class="text-slate-400">Reference</span><span class="font-mono">{{ $payment->payment_reference }}</span></div>
                <div class="flex justify-between"><span class="text-slate-400">Amount</span><span>₱{{ number_format($payment->amount, 2) }}</span></div>
            </div>
            <a href="{{ route('client.login') }}" class="inline-block w-full px-5 py-3 bg-blue-700 text-white rounded-lg font-medium hover:bg-blue-800">Go to My Account</a>
        @else
            <div class="text-5xl mb-4">⏳</div>
            <h1 class="text-xl font-bold text-amber-700 mb-2">Payment Processing</h1>
            <p class="text-slate-500 mb-6">We're confirming your payment with GCash. This usually takes just a few seconds — please check your account shortly.</p>
            <a href="{{ route('client.login') }}" class="inline-block w-full px-5 py-3 bg-blue-700 text-white rounded-lg font-medium hover:bg-blue-800">Go to My Account</a>
        @endif
    </div>
</body>
</html>
