<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class IsClient
{
    public function handle(Request $request, Closure $next): Response
    {
        $client = $request->user('client');

        if (!$client) {
            return redirect()->route('client.login');
        }

        if (!$client->is_active) {
            auth('client')->logout();
            return redirect()->route('client.login')->withErrors([
                'account_number' => 'Your account has been disabled. Please contact JM WIFI support.',
            ]);
        }

        return $next($request);
    }
}
