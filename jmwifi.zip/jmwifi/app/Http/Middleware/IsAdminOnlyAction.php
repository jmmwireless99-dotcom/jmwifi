<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Staff can view/manage clients and payments but cannot touch system settings,
 * router credentials, or user management. Apply to admin-only sub-routes
 * inside otherwise shared admin/staff controllers.
 */
class IsAdminOnlyAction
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user('web');

        if (!$user || !$user->isAdmin()) {
            abort(403, 'Only administrators can perform this action.');
        }

        return $next($request);
    }
}
