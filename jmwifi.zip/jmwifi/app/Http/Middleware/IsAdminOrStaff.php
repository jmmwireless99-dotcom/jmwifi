<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class IsAdminOrStaff
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user('web');

        if (!$user || !in_array($user->role, ['admin', 'staff'], true)) {
            abort(403, 'You do not have access to this area.');
        }

        if (!$user->is_active) {
            auth('web')->logout();
            return redirect()->route('login')->withErrors([
                'email' => 'Your account has been deactivated. Contact the administrator.',
            ]);
        }

        return $next($request);
    }
}
