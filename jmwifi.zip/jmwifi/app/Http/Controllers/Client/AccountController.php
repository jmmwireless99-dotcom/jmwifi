<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Services\MikroTik\MikroTikService;

class AccountController extends Controller
{
    public function dashboard(MikroTikService $mikrotik)
    {
        $client = Auth::guard('client')->user();

        if ($client->isExpired()) {
            return redirect()->route('client.expired');
        }

        $client->load('plan', 'router');
        $recentPayments = $client->payments()->latest()->limit(5)->get();

        return view('client.dashboard', compact('client', 'recentPayments'));
    }

    public function myAccount()
    {
        $client = Auth::guard('client')->user()->load('plan', 'primaryLocation');

        return view('client.account', compact('client'));
    }

    public function updateProfile(Request $request)
    {
        $client = Auth::guard('client')->user();

        $validated = $request->validate([
            'contact_number' => ['nullable', 'string', 'max:50'],
            'email' => ['nullable', 'email', 'max:255'],
            'address' => ['nullable', 'string', 'max:500'],
            'password' => ['nullable', 'string', 'min:6', 'confirmed'],
        ]);

        if (!empty($validated['password'])) {
            $validated['password'] = Hash::make($validated['password']);
        } else {
            unset($validated['password']);
        }

        $client->update($validated);

        return back()->with('success', 'Profile updated.');
    }
}
