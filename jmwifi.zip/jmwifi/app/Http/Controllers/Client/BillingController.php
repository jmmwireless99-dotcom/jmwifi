<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App\Services\PayMongo\PayMongoService;

class BillingController extends Controller
{
    public function payBills()
    {
        $client = Auth::guard('client')->user()->load('plan');

        return view('client.pay-bills', compact('client'));
    }

    public function advancePayment()
    {
        $client = Auth::guard('client')->user()->load('plan');

        return view('client.advance-payment', compact('client'));
    }

    /**
     * Create a PayMongo GCash checkout session and redirect the client
     * to PayMongo's hosted payment page.
     */
    public function checkout(Request $request, PayMongoService $payMongo)
    {
        $client = Auth::guard('client')->user();

        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:1'],
            'purpose' => ['required', 'in:renewal,advance'],
        ]);

        try {
            $payment = $payMongo->createCheckoutForClient(
                $client,
                (float) $validated['amount'],
                $validated['purpose']
            );

            return redirect($payment->paymongo_checkout_url);
        } catch (\Exception $e) {
            return back()->with('error', 'Could not start payment: ' . $e->getMessage());
        }
    }

    public function history()
    {
        $client = Auth::guard('client')->user();
        $payments = $client->payments()->latest()->paginate(15);

        return view('client.payment-history', compact('payments'));
    }

    public function receipt(Payment $payment)
    {
        $client = Auth::guard('client')->user();

        if ($payment->client_id !== $client->id) {
            abort(403);
        }

        if ($payment->status !== 'paid') {
            abort(404, 'Receipt not available — payment not completed.');
        }

        return view('client.receipt', compact('payment'));
    }

    /**
     * Manual GCash proof-of-payment submission for clients who transferred
     * money directly instead of using the PayMongo checkout flow.
     */
    public function submitProof(Request $request)
    {
        $client = Auth::guard('client')->user();

        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:1'],
            'reference_number' => ['required', 'string', 'max:255'],
            'proof_image' => ['required', 'image', 'max:5120'],
            'purpose' => ['required', 'in:renewal,advance'],
        ]);

        $path = $request->file('proof_image')->store('proofs', 'private');

        Payment::create([
            'payment_reference' => Payment::generateReference(),
            'client_id' => $client->id,
            'amount' => $validated['amount'],
            'method' => 'manual_gcash',
            'purpose' => $validated['purpose'],
            'proof_image_path' => $path,
            'notes' => "Client-submitted reference: {$validated['reference_number']}",
            'status' => 'pending',
        ]);

        return back()->with('success', 'Proof of payment submitted. An admin will verify it shortly.');
    }
}
