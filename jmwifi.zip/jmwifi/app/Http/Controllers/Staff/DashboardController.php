<?php

namespace App\Http\Controllers\Staff;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Payment;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_clients' => Client::count(),
            'active_clients' => Client::where('billing_status', 'active')->count(),
            'expired_clients' => Client::where('billing_status', 'expired')->count(),
            'online_clients' => Client::where('connection_status', 'online')->count(),
        ];

        $recentPayments = Payment::with('client')->where('status', 'paid')->latest('paid_at')->limit(10)->get();
        $pendingProofs = Payment::with('client')
            ->where('method', 'manual_gcash')
            ->where('status', 'pending')
            ->latest()
            ->limit(10)
            ->get();

        return view('staff.dashboard', compact('stats', 'recentPayments', 'pendingProofs'));
    }
}
