<?php

namespace App\Http\Controllers\Webhooks;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Services\PayMongo\PayMongoService;
use App\Services\PayMongo\PaymentProcessor;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;

class PayMongoWebhookController extends Controller
{
    public function __construct(
        protected PayMongoService $payMongo,
        protected PaymentProcessor $processor
    ) {
    }

    /**
     * PayMongo POSTs every event (checkout completed, payment paid/failed,
     * etc.) here. We verify the signature first — never trust the payload
     * before that — then only act on events that indicate a successful payment.
     *
     * Configure this URL in the PayMongo dashboard as:
     *   https://yourdomain.com/webhooks/paymongo
     */
    public function handle(Request $request)
    {
        $signatureHeader = $request->header('Paymongo-Signature');
        $rawPayload = $request->getContent();

        if (!$signatureHeader || !$this->payMongo->verifyWebhookSignature($rawPayload, $signatureHeader)) {
            Log::warning('PayMongo webhook: invalid or missing signature', [
                'ip' => $request->ip(),
            ]);

            return response()->json(['error' => 'Invalid signature'], Response::HTTP_UNAUTHORIZED);
        }

        $payload = $request->json()->all();
        $eventType = $payload['data']['attributes']['type'] ?? null;

        Log::info('PayMongo webhook received', ['type' => $eventType]);

        try {
            match ($eventType) {
                'checkout_session.payment.paid' => $this->handleCheckoutPaid($payload),
                'payment.paid' => $this->handlePaymentPaid($payload),
                'payment.failed' => $this->handlePaymentFailed($payload),
                default => Log::info("PayMongo webhook: unhandled event type '{$eventType}'"),
            };
        } catch (\Exception $e) {
            Log::error('PayMongo webhook processing error: ' . $e->getMessage());
            // Still return 200 so PayMongo doesn't endlessly retry a payload
            // we already understand but failed to fully process; the admin
            // can reconcile manually via "Verify with PayMongo".
            report($e);
        }

        // Always acknowledge receipt quickly so PayMongo doesn't retry/timeout.
        return response()->json(['received' => true]);
    }

    protected function handleCheckoutPaid(array $payload): void
    {
        $checkoutData = $payload['data']['attributes']['data'] ?? null;
        $checkoutId = $checkoutData['id'] ?? null;

        if (!$checkoutId) {
            return;
        }

        $payment = Payment::where('paymongo_checkout_id', $checkoutId)->first();

        if (!$payment) {
            Log::warning("PayMongo webhook: no local payment found for checkout {$checkoutId}");
            return;
        }

        $paymentId = $checkoutData['attributes']['payments'][0]['id'] ?? null;

        $this->processor->markAsPaid($payment, $paymentId, $checkoutData);
    }

    protected function handlePaymentPaid(array $payload): void
    {
        $paymentData = $payload['data']['attributes']['data'] ?? null;
        $paymentId = $paymentData['id'] ?? null;
        $checkoutId = $paymentData['attributes']['source']['id'] ?? null;

        $payment = $checkoutId
            ? Payment::where('paymongo_checkout_id', $checkoutId)->first()
            : Payment::where('paymongo_payment_id', $paymentId)->first();

        if (!$payment) {
            Log::warning("PayMongo webhook: no local payment found for payment.paid event (payment_id={$paymentId})");
            return;
        }

        $this->processor->markAsPaid($payment, $paymentId, $paymentData);
    }

    protected function handlePaymentFailed(array $payload): void
    {
        $paymentData = $payload['data']['attributes']['data'] ?? null;
        $checkoutId = $paymentData['attributes']['source']['id'] ?? null;

        if (!$checkoutId) {
            return;
        }

        $payment = Payment::where('paymongo_checkout_id', $checkoutId)->first();

        if ($payment && $payment->status === 'pending') {
            $payment->update([
                'status' => 'failed',
                'paymongo_status' => 'failed',
                'paymongo_raw_response' => $paymentData,
            ]);
        }
    }
}
