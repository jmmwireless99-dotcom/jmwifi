<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Services\PayMongo\PayMongoService;
use App\Services\PayMongo\PaymentProcessor;
use Illuminate\Http\Request;

class PaymentResultController extends Controller
{
    /**
     * PayMongo redirects the browser here after checkout. This is a
     * best-effort UX confirmation only — the *authoritative* update
     * always comes from the webhook (PayMongoWebhookController), since
     * a person could close the tab before this page even loads.
     * We do a live status check here so the page can show "Paid!"
     * immediately rather than "pending" if the webhook hasn't landed yet.
     */
    public function success(Request $request, PayMongoService $payMongo, PaymentProcessor $processor)
    {
        $reference = $request->query('ref');
        $payment = Payment::where('payment_reference', $reference)->first();

        if ($payment && $payment->status !== 'paid' && $payment->paymongo_checkout_id) {
            try {
                $data = $payMongo->getCheckoutStatus($payment->paymongo_checkout_id);
                $status = $data['attributes']['payment_status'] ?? null;

                if ($status === 'paid') {
                    $paymentId = $data['attributes']['payments'][0]['id'] ?? null;
                    $processor->markAsPaid($payment, $paymentId, $data);
                }
            } catch (\Exception $e) {
                report($e);
            }
        }

        return view('public.payment-success', compact('payment'));
    }

    public function failed(Request $request)
    {
        $reference = $request->query('ref');
        $payment = Payment::where('payment_reference', $reference)->first();

        return view('public.payment-failed', compact('payment'));
    }
}
