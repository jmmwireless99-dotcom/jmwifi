<?php

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Payment;
use App\Services\PayMongo\PayMongoService;
use App\Services\PayMongo\PaymentProcessor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ExpiredPortalController extends Controller
{
    /**
     * Public-facing "your account is expired" page. If the visitor is
     * logged in as a client, show their real balance; otherwise show a
     * generic message prompting them to log in.
     */
    public function show()
    {
        $client = Auth::guard('client')->user();

        if (!$client) {
            return view('public.expired', ['client' => null]);
        }

        $client->load('plan');
        $amountDue = $client->monthly_rate;

        return view('public.expired', compact('client', 'amountDue'));
    }

    public function createPayment(Request $request, PayMongoService $payMongo)
    {
        $client = Auth::guard('client')->user();

        if (!$client) {
            return redirect()->route('client.login');
        }

        $amount = $client->monthly_rate;

        try {
            $payment = $payMongo->createCheckoutForClient($client, $amount, 'renewal');
            return redirect($payment->paymongo_checkout_url);
        } catch (\Exception $e) {
            return back()->with('error', 'Could not start payment: ' . $e->getMessage());
        }
    }
}
