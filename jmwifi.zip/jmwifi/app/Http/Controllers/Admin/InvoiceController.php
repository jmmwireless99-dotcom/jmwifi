<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Client;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function index(Request $request)
    {
        $query = Invoice::with('client');

        if ($request->filled('status')) {
            $query->where('status', $request->string('status'));
        }

        $invoices = $query->latest()->paginate(25)->withQueryString();

        return view('admin.invoices.index', compact('invoices'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'client_id' => ['required', 'exists:clients,id'],
            'amount' => ['required', 'numeric', 'min:1'],
            'due_date' => ['required', 'date'],
            'billing_period_start' => ['nullable', 'date'],
            'billing_period_end' => ['nullable', 'date'],
            'notes' => ['nullable', 'string'],
        ]);

        $validated['invoice_number'] = Invoice::generateInvoiceNumber();
        $validated['status'] = 'unpaid';

        $invoice = Invoice::create($validated);

        return redirect()->route('admin.invoices.index')->with('success', "Invoice {$invoice->invoice_number} created.");
    }

    public function show(Invoice $invoice)
    {
        $invoice->load('client', 'payments');
        return view('admin.invoices.show', compact('invoice'));
    }

    public function destroy(Invoice $invoice)
    {
        if ($invoice->status === 'paid') {
            return back()->with('error', 'Cannot delete a paid invoice.');
        }

        $invoice->delete();

        return back()->with('success', 'Invoice deleted.');
    }
}
