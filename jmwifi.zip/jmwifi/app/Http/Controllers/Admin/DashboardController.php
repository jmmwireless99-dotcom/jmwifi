<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Payment;
use App\Models\Router;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_clients' => Client::count(),
            'active_clients' => Client::where('billing_status', 'active')->count(),
            'expired_clients' => Client::where('billing_status', 'expired')->count(),
            'online_clients' => Client::where('connection_status', 'online')->count(),
            'offline_clients' => Client::where('connection_status', 'offline')->count(),
            'router_offline_clients' => Client::where('connection_status', 'router_offline')->count(),
        ];

        $routers = Router::all();
        $routersOnline = $routers->where('status', 'online')->count();
        $routersTotal = $routers->count();

        $monthlyCollection = Payment::where('status', 'paid')
            ->whereMonth('paid_at', now()->month)
            ->whereYear('paid_at', now()->year)
            ->sum('amount');

        $pendingPayments = Payment::where('status', 'pending')->count();
        $pendingPaymentsAmount = Payment::where('status', 'pending')->sum('amount');

        $recentPayments = Payment::with('client')
            ->where('status', 'paid')
            ->latest('paid_at')
            ->limit(10)
            ->get();

        // 6-month collection trend for a dashboard chart
        $collectionTrend = Payment::select(
                DB::raw("DATE_FORMAT(paid_at, '%Y-%m') as month"),
                DB::raw('SUM(amount) as total')
            )
            ->where('status', 'paid')
            ->where('paid_at', '>=', Carbon::now()->subMonths(5)->startOfMonth())
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        $vpsUsage = $this->getVpsResourceUsage();

        return view('admin.dashboard', compact(
            'stats',
            'routers',
            'routersOnline',
            'routersTotal',
            'monthlyCollection',
            'pendingPayments',
            'pendingPaymentsAmount',
            'recentPayments',
            'collectionTrend',
            'vpsUsage'
        ));
    }

    /**
     * Best-effort VPS resource snapshot (CPU load, RAM, disk).
     * Reads directly from /proc and disk_free_space — no extra PHP
     * extensions required, but gracefully degrades to nulls if the
     * hosting environment restricts access (e.g. some shared hosts).
     */
    protected function getVpsResourceUsage(): array
    {
        $usage = ['cpu_load' => null, 'ram_used_percent' => null, 'disk_used_percent' => null];

        try {
            if (function_exists('sys_getloadavg')) {
                $load = sys_getloadavg();
                $usage['cpu_load'] = round($load[0], 2);
            }

            if (is_readable('/proc/meminfo')) {
                $meminfo = file_get_contents('/proc/meminfo');
                preg_match('/MemTotal:\s+(\d+)/', $meminfo, $total);
                preg_match('/MemAvailable:\s+(\d+)/', $meminfo, $available);

                if (!empty($total[1]) && !empty($available[1])) {
                    $totalKb = (int) $total[1];
                    $availableKb = (int) $available[1];
                    $usedPercent = (($totalKb - $availableKb) / $totalKb) * 100;
                    $usage['ram_used_percent'] = round($usedPercent, 1);
                }
            }

            $diskTotal = @disk_total_space('/');
            $diskFree = @disk_free_space('/');

            if ($diskTotal && $diskFree) {
                $usage['disk_used_percent'] = round((($diskTotal - $diskFree) / $diskTotal) * 100, 1);
            }
        } catch (\Throwable $e) {
            // Resource monitoring is a nice-to-have; never break the dashboard over it.
        }

        return $usage;
    }
}
