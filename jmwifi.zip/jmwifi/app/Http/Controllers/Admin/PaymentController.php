<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\Client;
use App\Services\PayMongo\PayMongoService;
use App\Services\PayMongo\PaymentProcessor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;

class PaymentController extends Controller
{
    public function index(Request $request)
    {
        $query = Payment::with('client');

        if ($request->filled('status')) {
            $query->where('status', $request->string('status'));
        }

        if ($request->filled('method')) {
            $query->where('method', $request->string('method'));
        }

        if ($request->filled('search')) {
            $search = $request->string('search');
            $query->where(function ($q) use ($search) {
                $q->where('payment_reference', 'like', "%{$search}%")
                  ->orWhereHas('client', fn ($c) => $c->where('full_name', 'like', "%{$search}%"));
            });
        }

        $payments = $query->latest()->paginate(25)->withQueryString();

        return view('admin.payments.index', compact('payments'));
    }

    public function show(Payment $payment)
    {
        $payment->load('client', 'invoice', 'verifier');
        return view('admin.payments.show', compact('payment'));
    }

    /**
     * Record a manual payment (cash collected at the office, or a manual
     * GCash transfer) and immediately process it the same way an automatic
     * PayMongo webhook would.
     */
    public function storeManual(Request $request, PaymentProcessor $processor)
    {
        $validated = $request->validate([
            'client_id' => ['required', 'exists:clients,id'],
            'amount' => ['required', 'numeric', 'min:1'],
            'method' => ['required', 'in:cash,manual_gcash,other'],
            'notes' => ['nullable', 'string'],
        ]);

        $client = Client::findOrFail($validated['client_id']);

        $payment = Payment::create([
            'payment_reference' => Payment::generateReference(),
            'client_id' => $client->id,
            'amount' => $validated['amount'],
            'method' => $validated['method'],
            'purpose' => 'renewal',
            'status' => 'pending',
            'notes' => $validated['notes'] ?? null,
            'verified_by' => Auth::guard('web')->id(),
            'verified_at' => now(),
        ]);

        $processor->markAsPaid($payment);

        return redirect()->route('admin.payments.show', $payment)
            ->with('success', 'Payment recorded and client reconnected.');
    }

    /**
     * Approve a client-submitted proof-of-payment (manual GCash transfer
     * with uploaded screenshot), marking it paid.
     */
    public function approveProof(Payment $payment, PaymentProcessor $processor)
    {
        if ($payment->status === 'paid') {
            return back()->with('error', 'This payment was already verified.');
        }

        $payment->update([
            'verified_by' => Auth::guard('web')->id(),
            'verified_at' => now(),
        ]);

        $processor->markAsPaid($payment);

        return back()->with('success', 'Payment approved and client reconnected.');
    }

    public function rejectProof(Request $request, Payment $payment)
    {
        $validated = $request->validate(['notes' => ['required', 'string']]);

        $payment->update([
            'status' => 'failed',
            'notes' => $validated['notes'],
            'verified_by' => Auth::guard('web')->id(),
            'verified_at' => now(),
        ]);

        return back()->with('success', 'Payment proof rejected.');
    }

    /**
     * Serve a client's proof-of-payment image. Routed through here (rather
     * than a public URL) since the 'private' disk is intentionally not
     * web-accessible — only authenticated admin/staff should ever see
     * a client's uploaded payment screenshot.
     */
    public function proofImage(Payment $payment): StreamedResponse
    {
        if (!$payment->proof_image_path || !Storage::disk('private')->exists($payment->proof_image_path)) {
            abort(404);
        }

        return Storage::disk('private')->response($payment->proof_image_path);
    }

    /**
     * Fallback manual check against PayMongo directly, in case a webhook
     * was missed (e.g. firewall blocked PayMongo's callback once).
     */
    public function verifyWithPayMongo(Payment $payment, PayMongoService $payMongo, PaymentProcessor $processor)
    {
        if (!$payment->paymongo_checkout_id) {
            return back()->with('error', 'This payment has no PayMongo checkout session to verify.');
        }

        try {
            $data = $payMongo->getCheckoutStatus($payment->paymongo_checkout_id);
            $status = $data['attributes']['payment_status'] ?? $data['attributes']['status'] ?? null;

            if ($status === 'paid') {
                $paymentId = $data['attributes']['payments'][0]['id'] ?? null;
                $processor->markAsPaid($payment, $paymentId, $data);
                return back()->with('success', 'Verified with PayMongo: payment confirmed and client reconnected.');
            }

            return back()->with('error', "PayMongo reports status: {$status}. Not yet paid.");
        } catch (\Exception $e) {
            return back()->with('error', 'Could not verify with PayMongo: ' . $e->getMessage());
        }
    }
}
