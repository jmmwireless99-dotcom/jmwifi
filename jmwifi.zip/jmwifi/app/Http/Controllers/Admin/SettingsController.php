<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SystemSetting;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class SettingsController extends Controller
{
    public function index()
    {
        $settings = [
            'company_name' => SystemSetting::get('company_name', 'JM WIFI'),
            'support_contact' => SystemSetting::get('support_contact', ''),
            'billing_cycle_days' => SystemSetting::get('billing_cycle_days', 30),
            'expiry_warning_days' => SystemSetting::get('expiry_warning_days', 3),
            'gcash_qr_image' => SystemSetting::get('gcash_qr_image', ''),
        ];

        $staffUsers = User::where('role', '!=', 'admin')->orWhere('role', 'admin')->orderBy('name')->get();

        return view('admin.settings.index', compact('settings', 'staffUsers'));
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'company_name' => ['required', 'string', 'max:255'],
            'support_contact' => ['nullable', 'string', 'max:255'],
            'billing_cycle_days' => ['required', 'integer', 'min:1', 'max:365'],
            'expiry_warning_days' => ['required', 'integer', 'min:0', 'max:30'],
        ]);

        SystemSetting::set('company_name', $validated['company_name']);
        SystemSetting::set('support_contact', $validated['support_contact'] ?? '');
        SystemSetting::set('billing_cycle_days', $validated['billing_cycle_days'], 'integer', 'billing');
        SystemSetting::set('expiry_warning_days', $validated['expiry_warning_days'], 'integer', 'billing');

        return back()->with('success', 'Settings updated.');
    }

    public function storeUser(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', Rule::unique('users', 'email')],
            'password' => ['required', 'string', 'min:6'],
            'role' => ['required', Rule::in(['admin', 'staff'])],
        ]);

        $validated['password'] = Hash::make($validated['password']);

        User::create($validated);

        return back()->with('success', 'User account created.');
    }

    public function toggleUser(User $user)
    {
        $user->update(['is_active' => !$user->is_active]);

        return back()->with('success', $user->is_active ? 'User activated.' : 'User deactivated.');
    }
}
