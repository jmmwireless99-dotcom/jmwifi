<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\Plan;
use App\Models\Router;
use App\Services\MikroTik\MikroTikService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class ClientController extends Controller
{
    public function index(Request $request)
    {
        $query = Client::with(['plan', 'router']);

        if ($request->filled('search')) {
            $search = $request->string('search');
            $query->where(function ($q) use ($search) {
                $q->where('full_name', 'like', "%{$search}%")
                  ->orWhere('account_number', 'like', "%{$search}%")
                  ->orWhere('pppoe_username', 'like', "%{$search}%")
                  ->orWhere('contact_number', 'like', "%{$search}%");
            });
        }

        if ($request->filled('billing_status')) {
            $query->where('billing_status', $request->string('billing_status'));
        }

        if ($request->filled('connection_status')) {
            $query->where('connection_status', $request->string('connection_status'));
        }

        $clients = $query->orderBy('full_name')->paginate(25)->withQueryString();

        return view('admin.clients.index', compact('clients'));
    }

    public function create()
    {
        $plans = Plan::where('is_active', true)->get();
        $routers = Router::where('is_active', true)->get();

        return view('admin.clients.create', compact('plans', 'routers'));
    }

    public function store(Request $request, MikroTikService $mikrotik)
    {
        $validated = $this->validateClient($request);

        $validated['password'] = Hash::make($validated['password']);
        $validated['account_number'] = $validated['account_number'] ?? $this->generateAccountNumber();
        $validated['billing_status'] = $validated['billing_status'] ?? 'active';

        $client = Client::create($validated);

        if ($request->filled('latitude') && $request->filled('longitude')) {
            $client->locations()->create([
                'latitude' => $request->float('latitude'),
                'longitude' => $request->float('longitude'),
                'is_primary' => true,
            ]);
        }

        // Best-effort provisioning on the router; failure here doesn't block
        // creating the billing record — admin can retry sync later.
        if ($client->connection_type === 'pppoe' && $client->router_id) {
            $mikrotik->provisionClient($client);
        }

        return redirect()->route('admin.clients.show', $client)
            ->with('success', 'Client created successfully.');
    }

    public function show(Client $client)
    {
        $client->load(['plan', 'router', 'invoices', 'payments' => fn ($q) => $q->latest()->limit(10), 'locations', 'mikrotikLogs' => fn ($q) => $q->latest()->limit(20)]);

        return view('admin.clients.show', compact('client'));
    }

    public function edit(Client $client)
    {
        $plans = Plan::where('is_active', true)->get();
        $routers = Router::where('is_active', true)->get();

        return view('admin.clients.edit', compact('client', 'plans', 'routers'));
    }

    public function update(Request $request, Client $client)
    {
        $validated = $this->validateClient($request, $client->id);

        if (!empty($validated['password'])) {
            $validated['password'] = Hash::make($validated['password']);
        } else {
            unset($validated['password']);
        }

        $client->update($validated);

        if ($request->filled('latitude') && $request->filled('longitude')) {
            $client->locations()->updateOrCreate(
                ['is_primary' => true],
                ['latitude' => $request->float('latitude'), 'longitude' => $request->float('longitude')]
            );
        }

        return redirect()->route('admin.clients.show', $client)
            ->with('success', 'Client updated successfully.');
    }

    public function destroy(Client $client)
    {
        $client->delete();

        return redirect()->route('admin.clients.index')
            ->with('success', 'Client deleted.');
    }

    /**
     * Manual "refresh status" button on the client detail page —
     * forces a live MikroTik check instead of waiting for the scheduled sync.
     */
    public function refreshStatus(Client $client, MikroTikService $mikrotik)
    {
        $status = $mikrotik->checkClientStatus($client);

        $client->update([
            'connection_status' => $status,
            'last_synced_at' => now(),
            'last_seen_online_at' => $status === 'online' ? now() : $client->last_seen_online_at,
        ]);

        return back()->with('success', "Status refreshed: {$status}");
    }

    /**
     * Manual suspend/restore toggle for admin override (e.g. a client
     * pays cash at the office and staff want to reconnect immediately
     * without going through PayMongo).
     */
    public function toggleSuspend(Client $client, MikroTikService $mikrotik)
    {
        if ($client->billing_status === 'expired') {
            $mikrotik->restoreClient($client);
            $client->update(['billing_status' => 'active']);
            $message = 'Client restored and reconnected.';
        } else {
            $mikrotik->suspendClient($client);
            $client->update(['billing_status' => 'expired']);
            $message = 'Client suspended.';
        }

        return back()->with('success', $message);
    }

    protected function validateClient(Request $request, ?int $ignoreClientId = null): array
    {
        return $request->validate([
            'account_number' => ['nullable', 'string', Rule::unique('clients', 'account_number')->ignore($ignoreClientId)],
            'full_name' => ['required', 'string', 'max:255'],
            'address' => ['nullable', 'string', 'max:500'],
            'contact_number' => ['nullable', 'string', 'max:50'],
            'email' => ['nullable', 'email', 'max:255'],
            'password' => [$ignoreClientId ? 'nullable' : 'required', 'string', 'min:6'],
            'plan_id' => ['nullable', 'exists:plans,id'],
            'router_id' => ['nullable', 'exists:routers,id'],
            'connection_type' => ['required', Rule::in(['pppoe', 'ipoe'])],
            'pppoe_username' => ['nullable', 'string', Rule::unique('clients', 'pppoe_username')->ignore($ignoreClientId)],
            'pppoe_password' => ['nullable', 'string'],
            'mac_address' => ['nullable', 'string', Rule::unique('clients', 'mac_address')->ignore($ignoreClientId)],
            'ip_address' => ['nullable', 'ip'],
            'monthly_rate_override' => ['nullable', 'numeric', 'min:0'],
            'due_date' => ['nullable', 'date'],
            'expiration_date' => ['nullable', 'date'],
            'billing_status' => ['nullable', Rule::in(['active', 'expired', 'suspended', 'pending'])],
            'is_active' => ['nullable', 'boolean'],
            'latitude' => ['nullable', 'numeric', 'between:-90,90'],
            'longitude' => ['nullable', 'numeric', 'between:-180,180'],
        ]);
    }

    protected function generateAccountNumber(): string
    {
        $last = Client::orderByDesc('id')->first();
        $nextNumber = $last ? $last->id + 1 : 1;

        return 'JM-' . str_pad((string) $nextNumber, 5, '0', STR_PAD_LEFT);
    }
}
