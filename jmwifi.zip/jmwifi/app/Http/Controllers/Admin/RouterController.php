<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Router;
use App\Services\MikroTik\MikroTikConnection;
use App\Services\MikroTik\MikroTikConnectionException;
use App\Services\MikroTik\MikroTikService;
use Illuminate\Http\Request;
use RouterOS\Query;

class RouterController extends Controller
{
    public function index()
    {
        $routers = Router::withCount('clients')->get();
        return view('admin.routers.index', compact('routers'));
    }

    public function store(Request $request)
    {
        $validated = $this->validateRouter($request);

        Router::create($validated);

        return back()->with('success', 'Router added.');
    }

    public function update(Request $request, Router $router)
    {
        $validated = $this->validateRouter($request, $router->id);

        // Don't overwrite the password if the field was left blank on edit
        if (empty($validated['api_password'])) {
            unset($validated['api_password']);
        }

        $router->update($validated);

        return back()->with('success', 'Router updated.');
    }

    public function destroy(Router $router)
    {
        if ($router->clients()->exists()) {
            return back()->with('error', 'Cannot delete a router that has clients assigned to it.');
        }

        $router->delete();

        return back()->with('success', 'Router deleted.');
    }

    /**
     * "Test Connection" button — attempts a real API login and a trivial
     * query, reporting success/failure immediately rather than waiting
     * for the next scheduled sync.
     */
    public function testConnection(Router $router)
    {
        try {
            $connection = new MikroTikConnection($router);
            $identity = $connection->query(new Query('/system/identity/print'));

            $name = $identity[0]['name'] ?? 'Unknown';

            return back()->with('success', "Connected successfully. Router identity: {$name}");
        } catch (MikroTikConnectionException $e) {
            return back()->with('error', 'Connection failed: ' . $e->getMessage());
        }
    }

    public function syncNow(Router $router, MikroTikService $mikrotik)
    {
        $summary = $mikrotik->syncRouter($router);

        if (!empty($summary['errors'])) {
            return back()->with('error', implode(' | ', $summary['errors']));
        }

        return back()->with('success', "Synced. PPPoE: {$summary['pppoe_synced']}, IPoE: {$summary['ipoe_synced']}");
    }

    protected function validateRouter(Request $request, ?int $ignoreId = null): array
    {
        return $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'ip_address' => ['required', 'string', 'max:255'],
            'api_port' => ['required', 'integer', 'min:1', 'max:65535'],
            'use_ssl' => ['nullable', 'boolean'],
            'api_username' => ['required', 'string', 'max:255'],
            'api_password' => [$ignoreId ? 'nullable' : 'required', 'string'],
            'client_mode' => ['required', 'in:pppoe,ipoe,both'],
            'normal_pppoe_profile' => ['required', 'string', 'max:255'],
            'expired_pppoe_profile' => ['required', 'string', 'max:255'],
            'expired_address_list' => ['required', 'string', 'max:255'],
            'is_active' => ['nullable', 'boolean'],
        ]);
    }
}
