<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Client;
use App\Models\ClientLocation;
use Illuminate\Http\Request;

class MapController extends Controller
{
    public function index()
    {
        $googleMapsApiKey = config('services.google_maps.api_key');
        $defaultLat = config('services.google_maps.default_lat');
        $defaultLng = config('services.google_maps.default_lng');

        return view('admin.map.index', compact('googleMapsApiKey', 'defaultLat', 'defaultLng'));
    }

    /**
     * JSON feed of every client pin, with marker color pre-computed
     * (green = active/online, red = expired, gray = offline) so the
     * frontend just renders without re-deriving business logic.
     */
    public function pins()
    {
        $locations = ClientLocation::with('client.plan')
            ->where('is_primary', true)
            ->get();

        $pins = $locations->map(function (ClientLocation $loc) {
            $client = $loc->client;

            return [
                'id' => $client->id,
                'name' => $client->full_name,
                'account_number' => $client->account_number,
                'lat' => (float) $loc->latitude,
                'lng' => (float) $loc->longitude,
                'color' => $loc->marker_color,
                'billing_status' => $client->billing_status,
                'connection_status' => $client->connection_status,
                'plan' => $client->plan?->name,
                'expiration_date' => $client->expiration_date?->format('M d, Y'),
                'detail_url' => route('admin.clients.show', $client),
            ];
        });

        return response()->json($pins);
    }

    /**
     * Admin drags/drops a pin or enters coordinates manually to update
     * a client's saved location.
     */
    public function updateLocation(Request $request, Client $client)
    {
        $validated = $request->validate([
            'latitude' => ['required', 'numeric', 'between:-90,90'],
            'longitude' => ['required', 'numeric', 'between:-180,180'],
            'label' => ['nullable', 'string', 'max:255'],
        ]);

        $client->locations()->updateOrCreate(
            ['is_primary' => true],
            [
                'latitude' => $validated['latitude'],
                'longitude' => $validated['longitude'],
                'label' => $validated['label'] ?? null,
            ]
        );

        return back()->with('success', 'Client location updated.');
    }
}
