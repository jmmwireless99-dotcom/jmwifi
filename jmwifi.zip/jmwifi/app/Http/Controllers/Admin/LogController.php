<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MikroTikLog;
use Illuminate\Http\Request;

class LogController extends Controller
{
    public function index(Request $request)
    {
        $query = MikroTikLog::with('router', 'client');

        if ($request->filled('status')) {
            $query->where('status', $request->string('status'));
        }

        if ($request->filled('action')) {
            $query->where('action', $request->string('action'));
        }

        if ($request->filled('router_id')) {
            $query->where('router_id', $request->integer('router_id'));
        }

        $logs = $query->latest()->paginate(50)->withQueryString();

        return view('admin.logs.index', compact('logs'));
    }
}
