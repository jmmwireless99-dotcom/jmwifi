<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use Illuminate\Http\Request;

class PlanController extends Controller
{
    public function index()
    {
        $plans = Plan::withCount('clients')->orderBy('monthly_rate')->get();
        return view('admin.plans.index', compact('plans'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'monthly_rate' => ['required', 'numeric', 'min:0'],
            'speed_down' => ['nullable', 'string', 'max:50'],
            'speed_up' => ['nullable', 'string', 'max:50'],
            'description' => ['nullable', 'string'],
            'mikrotik_profile_name' => ['nullable', 'string', 'max:255'],
            'mikrotik_queue_name' => ['nullable', 'string', 'max:255'],
        ]);

        Plan::create($validated);

        return back()->with('success', 'Plan created.');
    }

    public function update(Request $request, Plan $plan)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'monthly_rate' => ['required', 'numeric', 'min:0'],
            'speed_down' => ['nullable', 'string', 'max:50'],
            'speed_up' => ['nullable', 'string', 'max:50'],
            'description' => ['nullable', 'string'],
            'mikrotik_profile_name' => ['nullable', 'string', 'max:255'],
            'mikrotik_queue_name' => ['nullable', 'string', 'max:255'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $plan->update($validated);

        return back()->with('success', 'Plan updated.');
    }

    public function destroy(Plan $plan)
    {
        if ($plan->clients()->exists()) {
            return back()->with('error', 'Cannot delete a plan that has clients assigned to it.');
        }

        $plan->delete();

        return back()->with('success', 'Plan deleted.');
    }
}
