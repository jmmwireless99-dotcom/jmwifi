<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;

class ClientLoginController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.client-login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'account_number' => ['required', 'string'],
            'password' => ['required', 'string'],
        ]);

        if (!Auth::guard('client')->attempt($credentials, $request->boolean('remember'))) {
            throw ValidationException::withMessages([
                'account_number' => 'Invalid account number or password.',
            ]);
        }

        $request->session()->regenerate();

        $client = Auth::guard('client')->user();

        if (!$client->is_active) {
            Auth::guard('client')->logout();
            throw ValidationException::withMessages([
                'account_number' => 'Your account has been disabled. Please contact JM WIFI support.',
            ]);
        }

        // Send expired clients straight to the payment portal instead of
        // a normal dashboard they can't fully use yet.
        if ($client->isExpired()) {
            return redirect()->route('client.expired');
        }

        return redirect()->intended(route('client.dashboard'));
    }

    public function logout(Request $request)
    {
        Auth::guard('client')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('client.login');
    }
}
