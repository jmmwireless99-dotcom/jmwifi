<?php

namespace App\Console\Commands;

use App\Models\Client;
use App\Jobs\SuspendClientJob;
use App\Notifications\ClientExpiredNotification;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Notification;
use Carbon\Carbon;

/**
 * Runs daily (see routes/console.php schedule). Finds every client whose
 * expiration_date has passed but who is still marked 'active', flips them
 * to 'expired', queues the MikroTik suspend action, and notifies the client.
 */
class CheckExpiredClients extends Command
{
    protected $signature = 'clients:check-expired';
    protected $description = 'Mark clients past their expiration date as expired and suspend them on MikroTik';

    public function handle(): int
    {
        $expiredClients = Client::where('billing_status', 'active')
            ->whereNotNull('expiration_date')
            ->whereDate('expiration_date', '<', Carbon::today())
            ->get();

        $this->info("Found {$expiredClients->count()} newly expired client(s).");

        foreach ($expiredClients as $client) {
            $client->update(['billing_status' => 'expired']);

            SuspendClientJob::dispatch($client->id);

            try {
                Notification::send($client, new ClientExpiredNotification());
            } catch (\Exception $e) {
                report($e);
            }

            $this->line(" - Suspended: {$client->full_name} ({$client->account_number})");
        }

        return self::SUCCESS;
    }
}
