<?php

namespace App\Console\Commands;

use App\Models\Router;
use App\Services\MikroTik\MikroTikService;
use Illuminate\Console\Command;

class SyncMikroTikRouters extends Command
{
    protected $signature = 'mikrotik:sync {router_id? : Sync only a specific router by ID}';
    protected $description = 'Sync client online/offline status from all (or one) MikroTik router';

    public function handle(MikroTikService $mikrotik): int
    {
        $routerId = $this->argument('router_id');

        $routers = $routerId
            ? Router::where('id', $routerId)->get()
            : Router::where('is_active', true)->get();

        if ($routers->isEmpty()) {
            $this->warn('No routers found to sync.');
            return self::SUCCESS;
        }

        foreach ($routers as $router) {
            $this->info("Syncing router: {$router->name} ({$router->ip_address})...");
            $summary = $mikrotik->syncRouter($router);

            $this->line("  PPPoE synced: {$summary['pppoe_synced']}, IPoE synced: {$summary['ipoe_synced']}");

            foreach ($summary['errors'] as $error) {
                $this->error("  {$error}");
            }
        }

        return self::SUCCESS;
    }
}
