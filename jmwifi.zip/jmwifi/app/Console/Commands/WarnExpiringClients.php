<?php

namespace App\Console\Commands;

use App\Models\Client;
use App\Notifications\ExpirationWarningNotification;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Notification;
use Carbon\Carbon;

class WarnExpiringClients extends Command
{
    protected $signature = 'clients:warn-expiring';
    protected $description = 'Notify clients whose accounts are about to expire';

    public function handle(): int
    {
        $warningDays = (int) config('services.mikrotik.warning_days_before_expiry', 3);
        $targetDate = Carbon::today()->addDays($warningDays);

        $clients = Client::where('billing_status', 'active')
            ->whereDate('expiration_date', '=', $targetDate)
            ->get();

        $this->info("Warning {$clients->count()} client(s) expiring on {$targetDate->toDateString()}.");

        foreach ($clients as $client) {
            try {
                Notification::send($client, new ExpirationWarningNotification($warningDays));
            } catch (\Exception $e) {
                report($e);
            }
        }

        return self::SUCCESS;
    }
}
