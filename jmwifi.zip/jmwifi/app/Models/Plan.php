<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Plan extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'monthly_rate',
        'speed_down',
        'speed_up',
        'description',
        'mikrotik_profile_name',
        'mikrotik_queue_name',
        'is_active',
    ];

    protected function casts(): array
    {
        return [
            'monthly_rate' => 'decimal:2',
            'is_active' => 'boolean',
        ];
    }

    public function clients()
    {
        return $this->hasMany(Client::class);
    }
}
