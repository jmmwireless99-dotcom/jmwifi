<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ClientLocation extends Model
{
    use HasFactory;

    protected $fillable = [
        'client_id',
        'latitude',
        'longitude',
        'label',
        'is_primary',
    ];

    protected function casts(): array
    {
        return [
            'latitude' => 'decimal:7',
            'longitude' => 'decimal:7',
            'is_primary' => 'boolean',
        ];
    }

    public function client()
    {
        return $this->belongsTo(Client::class);
    }

    /**
     * Marker color for the admin Google Map, derived from the client's
     * current state: green = active/online, red = expired, gray = offline.
     */
    public function getMarkerColorAttribute(): string
    {
        $client = $this->client;

        if (!$client) {
            return 'gray';
        }

        if ($client->billing_status === 'expired') {
            return 'red';
        }

        if ($client->connection_status === 'online') {
            return 'green';
        }

        return 'gray';
    }
}
