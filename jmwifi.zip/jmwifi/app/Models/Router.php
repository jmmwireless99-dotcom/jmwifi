<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Router extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'ip_address',
        'api_port',
        'use_ssl',
        'api_username',
        'api_password',
        'client_mode',
        'normal_pppoe_profile',
        'expired_pppoe_profile',
        'expired_address_list',
        'status',
        'last_checked_at',
        'last_error',
        'is_active',
    ];

    protected $hidden = [
        'api_password',
    ];

    protected function casts(): array
    {
        return [
            'api_password' => 'encrypted', // Laravel encrypts/decrypts transparently
            'use_ssl' => 'boolean',
            'is_active' => 'boolean',
            'last_checked_at' => 'datetime',
        ];
    }

    public function clients()
    {
        return $this->hasMany(Client::class);
    }

    public function mikrotikLogs()
    {
        return $this->hasMany(MikroTikLog::class);
    }

    public function isOnline(): bool
    {
        return $this->status === 'online';
    }
}
