<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class MikroTikLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'router_id',
        'client_id',
        'action',
        'status',
        'message',
        'payload',
    ];

    protected function casts(): array
    {
        return [
            'payload' => 'array',
        ];
    }

    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    public function client()
    {
        return $this->belongsTo(Client::class);
    }
}
