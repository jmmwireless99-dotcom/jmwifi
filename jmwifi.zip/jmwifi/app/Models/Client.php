<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;

class Client extends Authenticatable
{
    use HasFactory, Notifiable;

    /**
     * Clients log in with account_number instead of email.
     */
    public function username(): string
    {
        return 'account_number';
    }

    protected $fillable = [
        'account_number',
        'full_name',
        'address',
        'contact_number',
        'email',
        'password',
        'plan_id',
        'router_id',
        'connection_type',
        'pppoe_username',
        'pppoe_password',
        'mac_address',
        'ip_address',
        'monthly_rate_override',
        'due_date',
        'expiration_date',
        'last_payment_date',
        'billing_status',
        'connection_status',
        'last_seen_online_at',
        'last_synced_at',
        'is_active',
    ];

    protected $hidden = [
        'password',
        'pppoe_password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'password' => 'hashed',
            'due_date' => 'date',
            'expiration_date' => 'date',
            'last_payment_date' => 'date',
            'last_seen_online_at' => 'datetime',
            'last_synced_at' => 'datetime',
            'monthly_rate_override' => 'decimal:2',
            'is_active' => 'boolean',
        ];
    }

    public function plan()
    {
        return $this->belongsTo(Plan::class);
    }

    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    public function locations()
    {
        return $this->hasMany(ClientLocation::class);
    }

    public function primaryLocation()
    {
        return $this->hasOne(ClientLocation::class)->where('is_primary', true);
    }

    public function invoices()
    {
        return $this->hasMany(Invoice::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function mikrotikLogs()
    {
        return $this->hasMany(MikroTikLog::class);
    }

    /**
     * Effective monthly rate: override if set, otherwise the plan's rate.
     */
    public function getMonthlyRateAttribute(): float
    {
        return (float) ($this->monthly_rate_override ?? $this->plan?->monthly_rate ?? 0);
    }

    public function isExpired(): bool
    {
        return $this->billing_status === 'expired'
            || ($this->expiration_date && $this->expiration_date->isPast());
    }

    public function daysUntilExpiration(): ?int
    {
        if (!$this->expiration_date) {
            return null;
        }
        return (int) Carbon::today()->diffInDays($this->expiration_date, false);
    }

    public function scopeExpired($query)
    {
        return $query->where('billing_status', 'expired');
    }

    public function scopeActive($query)
    {
        return $query->where('billing_status', 'active');
    }

    public function scopeOnline($query)
    {
        return $query->where('connection_status', 'online');
    }
}
