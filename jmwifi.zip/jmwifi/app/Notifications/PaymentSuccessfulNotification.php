<?php

namespace App\Notifications;

use App\Models\Payment;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class PaymentSuccessfulNotification extends Notification
{
    use Queueable;

    public function __construct(public Payment $payment)
    {
    }

    public function via($notifiable): array
    {
        return ['database'];
    }

    public function toArray($notifiable): array
    {
        return [
            'title' => 'Payment Successful',
            'message' => "We received your payment of ₱{$this->payment->amount}. Your account is now active until "
                . $notifiable->expiration_date?->format('M d, Y') . '.',
            'payment_id' => $this->payment->id,
        ];
    }
}
