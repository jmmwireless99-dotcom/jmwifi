<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class ExpirationWarningNotification extends Notification
{
    use Queueable;

    public function __construct(public int $daysRemaining)
    {
    }

    public function via($notifiable): array
    {
        return ['database'];
    }

    public function toArray($notifiable): array
    {
        return [
            'title' => 'Your JM WIFI account is expiring soon',
            'message' => "Your account will expire in {$this->daysRemaining} day(s). Please pay your bill to avoid disconnection.",
        ];
    }
}
