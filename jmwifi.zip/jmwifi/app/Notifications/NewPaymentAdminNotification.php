<?php

namespace App\Notifications;

use App\Models\Payment;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class NewPaymentAdminNotification extends Notification
{
    use Queueable;

    public function __construct(public Payment $payment)
    {
    }

    public function via($notifiable): array
    {
        return ['database'];
    }

    public function toArray($notifiable): array
    {
        return [
            'title' => 'New Payment Received',
            'message' => "₱{$this->payment->amount} from {$this->payment->client->full_name} ({$this->payment->client->account_number})",
            'payment_id' => $this->payment->id,
            'client_id' => $this->payment->client_id,
            'amount' => (string) $this->payment->amount,
            'method' => $this->payment->method,
        ];
    }
}
