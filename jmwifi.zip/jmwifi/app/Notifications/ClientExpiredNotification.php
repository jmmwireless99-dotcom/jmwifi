<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;

class ClientExpiredNotification extends Notification
{
    use Queueable;

    public function via($notifiable): array
    {
        return ['database'];
    }

    public function toArray($notifiable): array
    {
        return [
            'title' => 'Your JM WIFI account has expired',
            'message' => 'Your account is now expired. Please pay your bill to reconnect.',
        ];
    }
}
