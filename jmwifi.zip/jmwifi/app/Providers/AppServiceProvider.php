<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\URL;
use Illuminate\Pagination\Paginator;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Force HTTPS URL generation in production so PayMongo redirect
        // URLs and the webhook URL are always https — required by PayMongo.
        if ($this->app->environment('production')) {
            URL::forceScheme('https');
        }

        // Use Tailwind-friendly pagination markup instead of Bootstrap.
        Paginator::useTailwind();
    }
}
