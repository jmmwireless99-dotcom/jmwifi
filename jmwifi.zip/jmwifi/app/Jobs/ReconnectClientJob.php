<?php

namespace App\Jobs;

use App\Models\Client;
use App\Services\MikroTik\MikroTikService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ReconnectClientJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 5;
    public array $backoff = [10, 30, 60, 300, 900]; // retry with growing delay if router is briefly unreachable

    public function __construct(public int $clientId)
    {
    }

    public function handle(MikroTikService $mikrotik): void
    {
        $client = Client::find($this->clientId);

        if (!$client) {
            return;
        }

        $restored = $mikrotik->restoreClient($client);

        if (!$restored) {
            // Router was unreachable or the client has no router/profile config.
            // Throwing lets Laravel's queue retry per $backoff above; after
            // the final attempt it lands in failed_jobs for admin review.
            $this->fail("Could not restore client #{$client->id} on MikroTik (router unreachable or misconfigured).");
        }
    }
}
