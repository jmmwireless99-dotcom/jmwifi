<?php

namespace App\Jobs;

use App\Models\Client;
use App\Services\MikroTik\MikroTikService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SuspendClientJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 5;
    public array $backoff = [10, 30, 60, 300, 900];

    public function __construct(public int $clientId)
    {
    }

    public function handle(MikroTikService $mikrotik): void
    {
        $client = Client::find($this->clientId);

        if (!$client) {
            return;
        }

        $suspended = $mikrotik->suspendClient($client);

        if (!$suspended) {
            $this->fail("Could not suspend client #{$client->id} on MikroTik (router unreachable or misconfigured).");
        }
    }
}
