<?php

namespace App\Jobs;

use App\Models\Router;
use App\Services\MikroTik\MikroTikService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SyncAllRoutersJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 1; // sync failures are expected (router offline) — don't retry, just log and move on

    public function handle(MikroTikService $mikrotik): void
    {
        $routers = Router::where('is_active', true)->get();

        foreach ($routers as $router) {
            $mikrotik->syncRouter($router);
        }
    }
}
