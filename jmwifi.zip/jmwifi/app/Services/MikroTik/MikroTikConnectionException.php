<?php

namespace App\Services\MikroTik;

use Exception;
use Throwable;

class MikroTikConnectionException extends Exception
{
    public function __construct(string $message, ?Throwable $previous = null)
    {
        parent::__construct($message, 0, $previous);
    }
}
