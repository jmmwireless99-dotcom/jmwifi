<?php

namespace App\Services\MikroTik;

use App\Models\Client;
use App\Models\Router as RouterModel;
use Carbon\Carbon;

/**
 * Single entry point the rest of the app uses for all MikroTik actions.
 * Hides whether a client is PPPoE or IPoE behind one consistent API,
 * and is the home for the "sync everything" routine used by the
 * scheduled job and the manual "Sync Now" admin button.
 */
class MikroTikService
{
    /**
     * Suspend a client on their router (move to expired state).
     * Returns true on success, false if it couldn't be applied (e.g. router offline).
     */
    public function suspendClient(Client $client): bool
    {
        if (!$client->router) {
            return false;
        }

        try {
            if ($client->connection_type === 'pppoe') {
                return (new PPPoEManager($client->router))->suspendClient($client);
            }

            return (new IPoEManager($client->router))->suspendClient($client);
        } catch (MikroTikConnectionException $e) {
            return false;
        }
    }

    /**
     * Restore a client on their router after successful payment.
     */
    public function restoreClient(Client $client): bool
    {
        if (!$client->router) {
            return false;
        }

        try {
            if ($client->connection_type === 'pppoe') {
                return (new PPPoEManager($client->router))->restoreClient($client);
            }

            return (new IPoEManager($client->router))->restoreClient($client);
        } catch (MikroTikConnectionException $e) {
            return false;
        }
    }

    /**
     * Create the router-side identity (PPP secret) for a brand new client.
     * IPoE clients don't need a "create" step beyond having their MAC/IP
     * recorded — DHCP/static config is typically pre-existing on the router.
     */
    public function provisionClient(Client $client): bool
    {
        if (!$client->router || $client->connection_type !== 'pppoe') {
            return false;
        }

        try {
            return (new PPPoEManager($client->router))->createSecret($client);
        } catch (MikroTikConnectionException $e) {
            return false;
        }
    }

    /**
     * Live online/offline check for a single client (used by client detail page,
     * "refresh status" buttons). Returns 'online' | 'offline' | 'router_offline'.
     */
    public function checkClientStatus(Client $client): string
    {
        if (!$client->router) {
            return 'unknown';
        }

        try {
            if ($client->connection_type === 'pppoe') {
                if (!$client->pppoe_username) {
                    return 'unknown';
                }
                $online = (new PPPoEManager($client->router))->isOnline($client->pppoe_username);
            } else {
                if (!$client->mac_address) {
                    return 'unknown';
                }
                $online = (new IPoEManager($client->router))->isOnline($client->mac_address);
            }

            return $online ? 'online' : 'offline';
        } catch (MikroTikConnectionException $e) {
            return 'router_offline';
        }
    }

    /**
     * Full reconciliation sync for one router: pulls PPPoE secrets/sessions
     * and/or DHCP leases/ARP, and updates every matching client's
     * connection_status in the database. This is what the scheduled job
     * and the "Sync Now" button both call.
     *
     * Returns a summary array for display/logging.
     */
    public function syncRouter(RouterModel $router): array
    {
        $summary = ['router' => $router->name, 'pppoe_synced' => 0, 'ipoe_synced' => 0, 'errors' => []];

        if (in_array($router->client_mode, ['pppoe', 'both'], true)) {
            try {
                $pppoeManager = new PPPoEManager($router);
                $secrets = $pppoeManager->fetchAllSecretsWithStatus();

                $clients = $router->clients()->where('connection_type', 'pppoe')->get();

                foreach ($clients as $client) {
                    $data = $secrets[$client->pppoe_username] ?? null;
                    $status = $data ? ($data['is_online'] ? 'online' : 'offline') : 'unknown';

                    $client->forceFill([
                        'connection_status' => $status,
                        'last_synced_at' => now(),
                        'last_seen_online_at' => $status === 'online' ? now() : $client->last_seen_online_at,
                    ])->save();

                    $summary['pppoe_synced']++;
                }
            } catch (MikroTikConnectionException $e) {
                $summary['errors'][] = 'PPPoE sync: ' . $e->getMessage();
                $this->markClientsRouterOffline($router, 'pppoe');
            }
        }

        if (in_array($router->client_mode, ['ipoe', 'both'], true)) {
            try {
                $ipoeManager = new IPoEManager($router);
                $leases = $ipoeManager->fetchAllLeasesWithStatus();

                $clients = $router->clients()->where('connection_type', 'ipoe')->get();

                foreach ($clients as $client) {
                    $mac = strtoupper((string) $client->mac_address);
                    $data = $leases[$mac] ?? null;
                    $status = $data ? ($data['is_online'] ? 'online' : 'offline') : 'unknown';

                    $client->forceFill([
                        'connection_status' => $status,
                        'ip_address' => $data['ip_address'] ?? $client->ip_address,
                        'last_synced_at' => now(),
                        'last_seen_online_at' => $status === 'online' ? now() : $client->last_seen_online_at,
                    ])->save();

                    $summary['ipoe_synced']++;
                }
            } catch (MikroTikConnectionException $e) {
                $summary['errors'][] = 'IPoE sync: ' . $e->getMessage();
                $this->markClientsRouterOffline($router, 'ipoe');
            }
        }

        return $summary;
    }

    /**
     * When a router can't be reached at all, every one of its clients
     * should show "router_offline" rather than a misleading "offline"
     * (which would imply we successfully checked and found them disconnected).
     */
    protected function markClientsRouterOffline(RouterModel $router, string $connectionType): void
    {
        $router->clients()
            ->where('connection_type', $connectionType)
            ->update([
                'connection_status' => 'router_offline',
                'last_synced_at' => Carbon::now(),
            ]);
    }
}
