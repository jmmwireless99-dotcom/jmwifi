<?php

namespace App\Services\MikroTik;

use App\Models\Client;
use App\Models\Router as RouterModel;
use RouterOS\Query;

/**
 * Manages IPoE/DHCP clients identified by MAC address.
 *
 * RouterOS concepts used:
 * - /ip/dhcp-server/lease : DHCP leases, used to detect "online" (active lease)
 *   and to enforce static IP/MAC binding for known clients.
 * - /ip/firewall/address-list : we add a client's IP to an "EXPIRED-CLIENTS"
 *   list when their billing expires; a firewall rule (set up once, manually,
 *   on the router) blocks/redirects any traffic from addresses in that list
 *   to the payment portal. Removing the IP from the list restores access.
 * - /ip/arp : used as a secondary online check (ARP table = device responding
 *   on the LAN even without an active DHCP lease, e.g. static IP clients).
 */
class IPoEManager
{
    protected MikroTikConnection $connection;
    protected RouterModel $router;

    public function __construct(RouterModel $router)
    {
        $this->router = $router;
        $this->connection = new MikroTikConnection($router);
    }

    /**
     * Fetch all DHCP leases + ARP entries, normalized by MAC address.
     * Used by the sync job to reconcile router state into the clients table.
     */
    public function fetchAllLeasesWithStatus(): array
    {
        $leases = $this->connection->query(new Query('/ip/dhcp-server/lease/print'));
        $arpEntries = $this->connection->query(new Query('/ip/arp/print'));

        $arpByMac = [];
        foreach ($arpEntries as $arp) {
            $mac = strtoupper($arp['mac-address'] ?? '');
            if ($mac) {
                $arpByMac[$mac] = $arp;
            }
        }

        $result = [];
        foreach ($leases as $lease) {
            $mac = strtoupper($lease['mac-address'] ?? '');
            if (!$mac) {
                continue;
            }

            $isBound = ($lease['status'] ?? '') === 'bound';
            $hasArp = isset($arpByMac[$mac]);

            $result[$mac] = [
                'mac_address' => $mac,
                'ip_address' => $lease['address'] ?? null,
                'status' => $lease['status'] ?? null,
                'is_online' => $isBound || $hasArp,
            ];
        }

        $this->connection->log('sync_ipoe', 'success', count($result) . ' leases fetched');

        return $result;
    }

    /**
     * Check whether a single MAC address currently has an active
     * DHCP lease or ARP entry (i.e. the device is connected/online).
     */
    public function isOnline(string $macAddress): bool
    {
        $mac = strtoupper($macAddress);

        $leaseQuery = (new Query('/ip/dhcp-server/lease/print'))
            ->where('mac-address', $mac)
            ->where('status', 'bound');

        if (count($this->connection->query($leaseQuery)) > 0) {
            return true;
        }

        $arpQuery = (new Query('/ip/arp/print'))->where('mac-address', $mac);

        return count($this->connection->query($arpQuery)) > 0;
    }

    /**
     * Suspend a client: add their IP (and/or MAC-bound IP) to the
     * router's expired address-list so the firewall rule restricts them
     * to the payment portal only.
     */
    public function suspendClient(Client $client): bool
    {
        if (!$client->ip_address) {
            $this->connection->log(
                'add_to_expired_list',
                'failed',
                'Client has no IP address recorded; cannot add to address-list',
                $client->id
            );
            return false;
        }

        // Avoid duplicate entries
        if ($this->isInExpiredList($client->ip_address)) {
            return true;
        }

        $addQuery = (new Query('/ip/firewall/address-list/add'))
            ->equal('list', $this->router->expired_address_list)
            ->equal('address', $client->ip_address)
            ->equal('comment', "JMWIFI-Client-{$client->id}-Expired");

        $this->connection->query($addQuery);

        $this->connection->log(
            'add_to_expired_list',
            'success',
            "Added {$client->ip_address} to '{$this->router->expired_address_list}'",
            $client->id
        );

        return true;
    }

    /**
     * Restore a client after payment: remove their IP from the expired
     * address-list, restoring normal firewall/queue treatment.
     */
    public function restoreClient(Client $client): bool
    {
        if (!$client->ip_address) {
            return false;
        }

        $entryId = $this->findAddressListEntryId($client->ip_address);

        if (!$entryId) {
            // Nothing to remove — already restored or never suspended.
            $this->connection->log(
                'remove_from_expired_list',
                'success',
                "No expired-list entry found for {$client->ip_address} (already clear)",
                $client->id
            );
            return true;
        }

        $removeQuery = (new Query('/ip/firewall/address-list/remove'))->equal('.id', $entryId);
        $this->connection->query($removeQuery);

        $this->connection->log(
            'remove_from_expired_list',
            'success',
            "Removed {$client->ip_address} from '{$this->router->expired_address_list}'",
            $client->id
        );

        return true;
    }

    protected function isInExpiredList(string $ip): bool
    {
        return $this->findAddressListEntryId($ip) !== null;
    }

    protected function findAddressListEntryId(string $ip): ?string
    {
        $query = (new Query('/ip/firewall/address-list/print'))
            ->where('list', $this->router->expired_address_list)
            ->where('address', $ip);

        $result = $this->connection->query($query);

        return $result[0]['.id'] ?? null;
    }
}
