<?php

namespace App\Services\MikroTik;

use App\Models\Router as RouterModel;
use App\Models\MikroTikLog;
use RouterOS\Client;
use RouterOS\Config;
use RouterOS\Query;
use Exception;
use Illuminate\Support\Facades\Log;

/**
 * Thin wrapper around evilfreelancer/routeros-api-php that:
 * - Opens a connection to a given Router model
 * - Updates the router's online/offline status as a side effect of connecting
 * - Logs every meaningful action to mikrotik_logs
 *
 * Usage:
 *   $conn = new MikroTikConnection($routerModel);
 *   $client = $conn->connect(); // throws MikroTikConnectionException on failure
 */
class MikroTikConnection
{
    protected RouterModel $router;
    protected ?Client $client = null;

    public function __construct(RouterModel $router)
    {
        $this->router = $router;
    }

    /**
     * Open (or reuse) a RouterOS API connection.
     *
     * @throws MikroTikConnectionException
     */
    public function connect(): Client
    {
        if ($this->client !== null) {
            return $this->client;
        }

        try {
            $config = new Config(
                host: $this->router->ip_address,
                user: $this->router->api_username,
                pass: $this->router->api_password, // auto-decrypted by Eloquent cast
                port: $this->router->use_ssl ? 8729 : $this->router->api_port,
                ssl: $this->router->use_ssl,
                timeout: config('services.mikrotik.timeout', 5),
                attempts: 1,
            );

            $this->client = new Client($config);

            $this->router->forceFill([
                'status' => 'online',
                'last_checked_at' => now(),
                'last_error' => null,
            ])->save();

            return $this->client;
        } catch (Exception $e) {
            $this->router->forceFill([
                'status' => 'offline',
                'last_checked_at' => now(),
                'last_error' => $e->getMessage(),
            ])->save();

            $this->log('router_health_check', 'failed', 'Connection failed: ' . $e->getMessage());

            Log::warning("MikroTik connection failed for router #{$this->router->id}: " . $e->getMessage());

            throw new MikroTikConnectionException(
                "Could not connect to router '{$this->router->name}': " . $e->getMessage(),
                previous: $e
            );
        }
    }

    /**
     * Run a RouterOS API query and return the array response.
     * Catches and rethrows as MikroTikConnectionException so callers
     * have one exception type to handle.
     */
    public function query(Query $query): array
    {
        $client = $this->connect();

        try {
            return $client->query($query)->read();
        } catch (Exception $e) {
            $this->router->forceFill([
                'status' => 'offline',
                'last_error' => $e->getMessage(),
            ])->save();

            throw new MikroTikConnectionException(
                "Query failed on router '{$this->router->name}': " . $e->getMessage(),
                previous: $e
            );
        }
    }

    public function log(string $action, string $status, ?string $message = null, ?int $clientId = null, ?array $payload = null): void
    {
        MikroTikLog::create([
            'router_id' => $this->router->id,
            'client_id' => $clientId,
            'action' => $action,
            'status' => $status,
            'message' => $message,
            'payload' => $payload,
        ]);
    }

    public function router(): RouterModel
    {
        return $this->router;
    }
}
