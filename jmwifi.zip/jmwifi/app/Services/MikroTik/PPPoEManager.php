<?php

namespace App\Services\MikroTik;

use App\Models\Client;
use App\Models\Router as RouterModel;
use RouterOS\Query;

/**
 * Manages MikroTik PPPoE secrets and active sessions for a single router.
 *
 * RouterOS concepts used:
 * - /ppp/secret      : the PPPoE username/password/profile definitions
 * - /ppp/active      : currently connected PPPoE sessions
 * - profile field    : determines speed/queue via RouterOS PPP profiles.
 *   We move a secret between `normal_pppoe_profile` and `expired_pppoe_profile`
 *   to enforce billing state, then kick the active session so the router
 *   re-authenticates the client under the new profile.
 */
class PPPoEManager
{
    protected MikroTikConnection $connection;
    protected RouterModel $router;

    public function __construct(RouterModel $router)
    {
        $this->router = $router;
        $this->connection = new MikroTikConnection($router);
    }

    /**
     * Pull all PPP secrets + active sessions from the router and return
     * a normalized array keyed by username. Used by the sync job to
     * reconcile router state into the clients table.
     */
    public function fetchAllSecretsWithStatus(): array
    {
        $secrets = $this->connection->query(new Query('/ppp/secret/print'));
        $active = $this->connection->query(new Query('/ppp/active/print'));

        $activeByUsername = [];
        foreach ($active as $session) {
            $name = $session['name'] ?? null;
            if ($name) {
                $activeByUsername[$name] = $session;
            }
        }

        $result = [];
        foreach ($secrets as $secret) {
            $username = $secret['name'] ?? null;
            if (!$username) {
                continue;
            }

            $result[$username] = [
                'username' => $username,
                'profile' => $secret['profile'] ?? null,
                'disabled' => ($secret['disabled'] ?? 'false') === 'true',
                'comment' => $secret['comment'] ?? null,
                'is_online' => isset($activeByUsername[$username]),
                'session' => $activeByUsername[$username] ?? null,
            ];
        }

        $this->connection->log('sync_pppoe', 'success', count($result) . ' secrets fetched');

        return $result;
    }

    /**
     * Check whether a single client's PPPoE username currently has an
     * active session on the router. Used for live "online/offline" checks.
     */
    public function isOnline(string $pppoeUsername): bool
    {
        $query = (new Query('/ppp/active/print'))
            ->where('name', $pppoeUsername);

        $result = $this->connection->query($query);

        return count($result) > 0;
    }

    /**
     * Suspend a client: move their secret to the EXPIRED profile and
     * disconnect any active session so the router re-authenticates them
     * (RouterOS applies the new profile only on reconnect).
     */
    public function suspendClient(Client $client): bool
    {
        if (!$client->pppoe_username) {
            return false;
        }

        $secretId = $this->findSecretId($client->pppoe_username);

        if (!$secretId) {
            $this->connection->log(
                'move_to_expired_profile',
                'failed',
                "Secret not found for username '{$client->pppoe_username}'",
                $client->id
            );
            return false;
        }

        $setQuery = (new Query('/ppp/secret/set'))
            ->equal('.id', $secretId)
            ->equal('profile', $this->router->expired_pppoe_profile);

        $this->connection->query($setQuery);

        $this->disconnectActiveSession($client->pppoe_username);

        $this->connection->log(
            'move_to_expired_profile',
            'success',
            "Moved '{$client->pppoe_username}' to profile '{$this->router->expired_pppoe_profile}'",
            $client->id
        );

        return true;
    }

    /**
     * Restore a client after successful payment: move their secret back
     * to the normal profile and disconnect so they reconnect immediately
     * with full access instead of waiting for their session to expire naturally.
     */
    public function restoreClient(Client $client): bool
    {
        if (!$client->pppoe_username) {
            return false;
        }

        $secretId = $this->findSecretId($client->pppoe_username);

        if (!$secretId) {
            $this->connection->log(
                'restore_normal_profile',
                'failed',
                "Secret not found for username '{$client->pppoe_username}'",
                $client->id
            );
            return false;
        }

        // Plan may define its own profile (different speed tiers); fall back
        // to the router's general "normal" profile if the plan doesn't specify one.
        $targetProfile = $client->plan?->mikrotik_profile_name
            ?: $this->router->normal_pppoe_profile;

        $setQuery = (new Query('/ppp/secret/set'))
            ->equal('.id', $secretId)
            ->equal('profile', $targetProfile);

        $this->connection->query($setQuery);

        $this->disconnectActiveSession($client->pppoe_username);

        $this->connection->log(
            'restore_normal_profile',
            'success',
            "Restored '{$client->pppoe_username}' to profile '{$targetProfile}'",
            $client->id
        );

        return true;
    }

    /**
     * Create a new PPP secret on the router for a newly added client.
     */
    public function createSecret(Client $client): bool
    {
        if (!$client->pppoe_username || !$client->pppoe_password) {
            return false;
        }

        $profile = $client->billing_status === 'expired'
            ? $this->router->expired_pppoe_profile
            : ($client->plan?->mikrotik_profile_name ?: $this->router->normal_pppoe_profile);

        $addQuery = (new Query('/ppp/secret/add'))
            ->equal('name', $client->pppoe_username)
            ->equal('password', $client->pppoe_password)
            ->equal('service', 'pppoe')
            ->equal('profile', $profile)
            ->equal('comment', "JMWIFI-Client-{$client->id}");

        $this->connection->query($addQuery);

        $this->connection->log('sync_pppoe', 'success', "Created secret for '{$client->pppoe_username}'", $client->id);

        return true;
    }

    public function disconnectActiveSession(string $pppoeUsername): void
    {
        $query = (new Query('/ppp/active/print'))->where('name', $pppoeUsername);
        $sessions = $this->connection->query($query);

        foreach ($sessions as $session) {
            if (!empty($session['.id'])) {
                $removeQuery = (new Query('/ppp/active/remove'))->equal('.id', $session['.id']);
                $this->connection->query($removeQuery);
            }
        }
    }

    protected function findSecretId(string $username): ?string
    {
        $query = (new Query('/ppp/secret/print'))->where('name', $username);
        $result = $this->connection->query($query);

        return $result[0]['.id'] ?? null;
    }
}
