<?php

namespace App\Services\PayMongo;

use App\Models\Client;
use App\Models\Payment;
use App\Models\Invoice;
use Illuminate\Support\Facades\Http;
use Exception;

/**
 * Wraps the PayMongo Checkout Sessions API for GCash payments.
 * Docs: https://developers.paymongo.com/reference/checkout-sessions
 *
 * Flow:
 * 1. createCheckoutForClient() -> opens a hosted checkout page, returns the URL
 * 2. Client pays via GCash on PayMongo's page
 * 3. PayMongo calls our webhook (see PayMongoWebhookController)
 * 4. verifyWebhookSignature() confirms the request really came from PayMongo
 * 5. handleSuccessfulPayment() updates the payment/invoice/client and
 *    triggers the MikroTik reconnect job
 */
class PayMongoService
{
    protected string $secretKey;
    protected string $baseUrl;

    public function __construct()
    {
        $this->secretKey = config('services.paymongo.secret_key');
        $this->baseUrl = config('services.paymongo.base_url');
    }

    protected function authHeader(): string
    {
        return 'Basic ' . base64_encode($this->secretKey . ':');
    }

    /**
     * Create a PayMongo Checkout Session for a client's renewal or
     * advance payment, restricted to GCash as the payment method.
     */
    public function createCheckoutForClient(Client $client, float $amount, string $purpose = 'renewal', ?Invoice $invoice = null): Payment
    {
        $reference = Payment::generateReference();

        $payload = [
            'data' => [
                'attributes' => [
                    'send_email_receipt' => false,
                    'show_description' => true,
                    'show_line_items' => true,
                    'payment_method_types' => ['gcash'],
                    'description' => "JM WIFI - {$client->full_name} ({$client->account_number})",
                    'line_items' => [[
                        'currency' => 'PHP',
                        'amount' => (int) round($amount * 100), // PayMongo uses centavos
                        'name' => $purpose === 'advance'
                            ? 'JM WIFI Advance Payment'
                            : 'JM WIFI Monthly Bill - ' . ($client->plan?->name ?? 'Internet Plan'),
                        'quantity' => 1,
                    ]],
                    'success_url' => config('services.paymongo.success_url') . '?ref=' . $reference,
                    'cancel_url' => config('services.paymongo.failed_url') . '?ref=' . $reference,
                    'metadata' => [
                        'client_id' => (string) $client->id,
                        'payment_reference' => $reference,
                        'purpose' => $purpose,
                    ],
                ],
            ],
        ];

        $response = Http::withHeaders([
            'Authorization' => $this->authHeader(),
            'Content-Type' => 'application/json',
        ])->post("{$this->baseUrl}/checkout_sessions", $payload);

        if ($response->failed()) {
            throw new Exception('PayMongo checkout creation failed: ' . $response->body());
        }

        $data = $response->json('data');

        $payment = Payment::create([
            'payment_reference' => $reference,
            'client_id' => $client->id,
            'invoice_id' => $invoice?->id,
            'amount' => $amount,
            'method' => 'gcash',
            'purpose' => $purpose,
            'paymongo_checkout_id' => $data['id'] ?? null,
            'paymongo_status' => $data['attributes']['status'] ?? 'awaiting_payment_method',
            'paymongo_checkout_url' => $data['attributes']['checkout_url'] ?? null,
            'paymongo_raw_response' => $data,
            'status' => 'pending',
        ]);

        return $payment;
    }

    /**
     * Verify that an incoming webhook request actually came from PayMongo
     * by recomputing the HMAC-SHA256 signature and comparing it.
     * PayMongo signature header format: t=<timestamp>,te=<test_sig>,li=<live_sig>
     */
    public function verifyWebhookSignature(string $payload, string $signatureHeader): bool
    {
        $webhookSecret = config('services.paymongo.webhook_secret');

        if (!$webhookSecret) {
            return false;
        }

        $parts = [];
        foreach (explode(',', $signatureHeader) as $pair) {
            [$key, $value] = array_pad(explode('=', $pair, 2), 2, null);
            $parts[$key] = $value;
        }

        $timestamp = $parts['t'] ?? null;
        $signature = $parts['li'] ?? ($parts['te'] ?? null); // live signature, fallback to test

        if (!$timestamp || !$signature) {
            return false;
        }

        $signedPayload = "{$timestamp}.{$payload}";
        $expectedSignature = hash_hmac('sha256', $signedPayload, $webhookSecret);

        return hash_equals($expectedSignature, $signature);
    }

    /**
     * Look up the live status of a checkout session directly from PayMongo
     * (used as a fallback/manual "verify payment" admin action, in case a
     * webhook was missed).
     */
    public function getCheckoutStatus(string $checkoutSessionId): array
    {
        $response = Http::withHeaders([
            'Authorization' => $this->authHeader(),
        ])->get("{$this->baseUrl}/checkout_sessions/{$checkoutSessionId}");

        if ($response->failed()) {
            throw new Exception('PayMongo status check failed: ' . $response->body());
        }

        return $response->json('data');
    }
}
