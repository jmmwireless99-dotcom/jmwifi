<?php

namespace App\Services\PayMongo;

use App\Models\Payment;
use App\Models\Client;
use App\Models\SystemSetting;
use App\Jobs\ReconnectClientJob;
use App\Notifications\PaymentSuccessfulNotification;
use App\Notifications\NewPaymentAdminNotification;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Carbon\Carbon;

/**
 * Central place where "a payment succeeded" gets turned into real account
 * changes. Called from:
 * - PayMongoWebhookController (automatic, via webhook)
 * - Admin\PaymentController (manual verification / cash / proof-of-payment approval)
 *
 * Keeping this in one service guarantees both paths apply identical logic
 * (extend expiration, clear expired flag, queue MikroTik reconnect, notify).
 */
class PaymentProcessor
{
    public function markAsPaid(Payment $payment, ?string $paymongoPaymentId = null, ?array $rawResponse = null): Payment
    {
        return DB::transaction(function () use ($payment, $paymongoPaymentId, $rawResponse) {

            if ($payment->status === 'paid') {
                return $payment; // idempotent — webhook may fire more than once
            }

            $payment->update([
                'status' => 'paid',
                'paid_at' => now(),
                'paymongo_payment_id' => $paymongoPaymentId ?? $payment->paymongo_payment_id,
                'paymongo_status' => 'paid',
                'paymongo_raw_response' => $rawResponse ?? $payment->paymongo_raw_response,
            ]);

            $client = $payment->client;

            if ($payment->invoice) {
                $payment->invoice->update([
                    'amount_paid' => $payment->invoice->amount_paid + $payment->amount,
                    'status' => ($payment->invoice->amount_paid + $payment->amount) >= $payment->invoice->amount
                        ? 'paid' : 'partial',
                    'paid_at' => now(),
                ]);
            }

            $this->extendClientExpiration($client, $payment);

            $client->update([
                'billing_status' => 'active',
                'last_payment_date' => now()->toDateString(),
            ]);

            // Reconnect on the router asynchronously so the webhook/HTTP
            // response isn't held up waiting on a RouterOS API round-trip.
            ReconnectClientJob::dispatch($client->id);

            $this->sendNotifications($client, $payment);

            return $payment;
        });
    }

    /**
     * Extend a client's expiration date based on the payment amount relative
     * to their monthly rate (so an advance payment of 2x the rate extends
     * 2 billing cycles). Renewal/partial payments of a normal month simply
     * extend exactly one cycle forward from the later of "today" or their
     * current expiration date (so paying early doesn't lose unused days).
     */
    protected function extendClientExpiration(Client $client, Payment $payment): void
    {
        $monthlyRate = $client->monthly_rate;
        $cycles = $monthlyRate > 0 ? max(1, (int) round($payment->amount / $monthlyRate)) : 1;

        $billingCycleDays = (int) SystemSetting::get('billing_cycle_days', 30);

        $baseDate = ($client->expiration_date && $client->expiration_date->isFuture())
            ? $client->expiration_date
            : Carbon::today();

        $client->expiration_date = $baseDate->copy()->addDays($billingCycleDays * $cycles);
        $client->due_date = $client->expiration_date->copy()->subDays(3);
        $client->save();
    }

    protected function sendNotifications(Client $client, Payment $payment): void
    {
        try {
            Notification::send($client, new PaymentSuccessfulNotification($payment));
        } catch (\Exception $e) {
            // Notification failure should never roll back a recorded payment
            report($e);
        }

        try {
            $admins = User::where('role', 'admin')->where('is_active', true)->get();
            Notification::send($admins, new NewPaymentAdminNotification($payment));
        } catch (\Exception $e) {
            report($e);
        }
    }
}
