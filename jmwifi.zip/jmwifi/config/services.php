<?php

return [

    'paymongo' => [
        'secret_key' => env('PAYMONGO_SECRET_KEY'),
        'public_key' => env('PAYMONGO_PUBLIC_KEY'),
        'webhook_secret' => env('PAYMONGO_WEBHOOK_SECRET'),
        'base_url' => env('PAYMONGO_BASE_URL', 'https://api.paymongo.com/v1'),
        'success_url' => env('PAYMONGO_SUCCESS_URL'),
        'failed_url' => env('PAYMONGO_FAILED_URL'),
    ],

    'google_maps' => [
        'api_key' => env('GOOGLE_MAPS_API_KEY'),
        'default_lat' => env('MAP_DEFAULT_LAT', 14.5995),
        'default_lng' => env('MAP_DEFAULT_LNG', 120.9842),
    ],

    'mikrotik' => [
        // Default connection timeout (seconds) for RouterOS API calls
        'timeout' => env('MIKROTIK_TIMEOUT', 5),
        // How many days before expiration to send a warning notification
        'warning_days_before_expiry' => env('MIKROTIK_WARNING_DAYS', 3),
    ],

];
