# JM WIFI Billing System — Testing Guide

Run through these checks after deployment, and again after any update to
the MikroTik or PayMongo integration code. Test in this order — later
sections depend on earlier ones working.

---

## 1. Basic Access

| Test | Steps | Expected Result |
|---|---|---|
| Admin login | Go to `/login`, sign in as admin | Redirected to Admin Dashboard |
| Staff login | Sign in as staff | Redirected to Staff Dashboard; no access to Settings/Routers/Plans |
| Client login | Go to `/client/login`, sign in with a test client's account number | Redirected to Client Dashboard |
| Wrong role blocked | Staff account tries visiting `/admin/settings` | 403 Forbidden |
| Inactive account blocked | Deactivate a user in Settings, try logging in as them | Login rejected with "deactivated" message |

---

## 2. MikroTik Connectivity

| Test | Steps | Expected Result |
|---|---|---|
| Add router | Admin → Routers → Add Router, fill in real MikroTik IP/credentials | Saved successfully |
| Test connection | Click "Test Connection" | Shows router identity name on success, or a clear error if unreachable |
| Manual sync | Click "Sync Now" on the router | Client connection statuses update; check `Admin → Logs` for `sync_pppoe`/`sync_ipoe` entries |
| Router offline handling | Temporarily block the VPS's access to the router (firewall rule), then Sync Now | Router status flips to "offline"; affected clients show "router_offline", not "offline" |
| Scheduled sync | Wait 5 minutes (or run `php artisan mikrotik:sync` manually) | `last_synced_at` timestamps update on clients automatically |

---

## 3. PPPoE Client Lifecycle

Use a **test PPPoE secret** on the router, not a real paying customer, for this section.

| Test | Steps | Expected Result |
|---|---|---|
| Provision | Add a client with connection_type=PPPoE, router assigned, valid username/password | A `/ppp/secret` is created on the router (`mikrotik_logs` shows `sync_pppoe` success) |
| Online detection | Connect a test device using that PPPoE login, then refresh client status | Client shows "online" |
| Suspend | Admin → Client → click "Suspend" | Secret's profile changes to `EXPIRED` profile on the router; active session is dropped; client must re-authenticate and gets the throttled/redirected profile |
| Restore | Click "Restore / Reconnect" | Secret's profile changes back to normal/plan profile; session is dropped so it reconnects immediately with full access |
| Auto-expire | Set a test client's `expiration_date` to yesterday, run `php artisan clients:check-expired` | Client's `billing_status` becomes `expired`; suspend job dispatches; check `mikrotik_logs` |

---

## 4. IPoE/DHCP Client Lifecycle

| Test | Steps | Expected Result |
|---|---|---|
| Online detection | Add a client with connection_type=IPoE and a real MAC address connected to the network, then Sync Now | Client shows "online" (lease or ARP entry found) |
| Suspend | Suspend the client | Their IP is added to the router's `EXPIRED-CLIENTS` address-list (`mikrotik_logs` shows `add_to_expired_list`) |
| Firewall behavior | With the client suspended, browse the internet from that device | Traffic is redirected/blocked per your firewall rule from Section 6 of the Install Guide |
| Restore | Restore the client | IP removed from `EXPIRED-CLIENTS`; normal access resumes |

---

## 5. PayMongo / GCash Payments (use Test Mode keys first!)

| Test | Steps | Expected Result |
|---|---|---|
| Checkout creation | Client Portal → Pay Bills → Pay with GCash | Redirected to a PayMongo-hosted checkout page |
| Successful test payment | On PayMongo's test checkout, use their documented test GCash flow to simulate success | Redirected to `/payment/success`; payment shows "Paid" |
| Webhook received | Check `storage/logs/laravel.log` after a test payment | Log line: "PayMongo webhook received" with type `checkout_session.payment.paid` or `payment.paid` |
| Auto-reconnect after payment | Suspend a test client, then have them pay via GCash checkout | Within a few seconds (queue worker dependent), client's billing_status → active, expiration_date extended, and a `ReconnectClientJob` runs (check `mikrotik_logs` for `restore_normal_profile` / `remove_from_expired_list`) |
| Webhook signature rejection | `curl -X POST https://yourdomain.com/webhooks/paymongo -d '{}'` (no signature header) | Returns 401 Unauthorized — confirms forged webhooks are rejected |
| Idempotency | Manually replay the same webhook payload twice (PayMongo sometimes retries) | Client is not double-charged or double-extended; second call is a no-op |
| Failed/cancelled payment | Start a checkout, then click "cancel" on PayMongo's page | Redirected to `/payment/failed`; no account changes made |

---

## 6. Manual Payments & Proof of Payment

| Test | Steps | Expected Result |
|---|---|---|
| Manual cash payment | Admin → Payments → Record Manual Payment, select client, enter amount, method=Cash | Payment marked paid immediately; client reconnect job dispatched |
| Client proof submission | Client Portal → Pay Bills → submit a GCash reference number + screenshot | Payment created with status "pending"; appears in Staff/Admin pending list |
| Proof approval | Admin/Staff → open the pending payment → Approve & Reconnect | Status becomes "paid"; client extended and reconnected |
| Proof rejection | Reject a submitted proof with a reason | Status becomes "failed"; client is notified the reason is recorded in notes |

---

## 7. Expired Client Portal

| Test | Steps | Expected Result |
|---|---|---|
| Auto-redirect | Log in as an expired client | Redirected straight to `/expired` instead of the dashboard |
| Amount due shown | View the expired page | Correct plan rate shown as amount due |
| Pay-to-reconnect | Click "Pay with GCash to Reconnect" | Same PayMongo checkout flow as Section 5; successful payment clears expired status |

---

## 8. Notifications

| Test | Steps | Expected Result |
|---|---|---|
| New payment → admin | Complete any successful payment | Admin notification created (check `notifications` table or build a notification bell UI) |
| Expiry warning | Set a client's expiration_date to (today + warning_days), run `php artisan clients:warn-expiring` | Client notification created |
| Expired notice | Run `php artisan clients:check-expired` on an overdue client | Client notification created |
| Payment success notice | Any successful payment | Client notification created with new expiration date |

---

## 9. Google Map

| Test | Steps | Expected Result |
|---|---|---|
| Pins load | Admin → Map | Pins appear for every client with a saved location |
| Marker colors | Compare an active/online client, an expired client, and an offline client | Green, red, and gray markers respectively |
| Location picker | Edit a client, set/update latitude+longitude | Marker moves to the new position on next map load |

---

## 10. Dashboard Accuracy

| Test | Steps | Expected Result |
|---|---|---|
| Counts match | Manually count clients by status in the Clients list; compare to Dashboard cards | Numbers match exactly |
| Monthly collection | Sum all `paid` payments for the current month manually | Matches "This Month's Collection" figure |
| Router status | Compare Dashboard's router online/offline indicator to a manual Test Connection | Matches |
| VPS resource usage | Compare CPU/RAM/Disk shown to `htop`/`df -h` on the actual VPS | Roughly matches (best-effort, not exact) |

---

## Notes on Test Mode vs Live Mode

- Always complete Sections 5–7 fully using PayMongo **test mode** keys before
  switching `.env` to live keys.
- PayMongo's test mode lets you simulate both successful and failed GCash
  payments without moving real money — check PayMongo's own docs for the
  current test-flow instructions, as their test checkout UI changes over time.
- Never test the "auto-suspend" flow against a router with real paying
  customers connected — always use a dedicated test PPPoE secret or test
  device's MAC address.
