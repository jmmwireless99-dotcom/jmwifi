# JM WIFI Billing System — VPS Installation Guide

This guide takes you from a fresh Ubuntu 22.04/24.04 VPS to a running billing
system with MikroTik sync, PayMongo/GCash payments, and the scheduled jobs
that auto-expire and auto-reconnect clients.

---

## 1. Server Requirements

- Ubuntu 22.04 or 24.04 VPS (2 vCPU / 2GB RAM minimum)
- PHP 8.2 or 8.3 with extensions: `mbstring`, `xml`, `curl`, `mysql`, `bcmath`, `zip`, `gd`
- Composer 2.x
- MySQL 8.0 (or MariaDB 10.6+)
- Nginx (recommended) or Apache
- A domain name pointed at the VPS, with HTTPS (PayMongo **requires** HTTPS for webhooks and redirect URLs)
- A MikroTik router with API access enabled (see Section 6)

---

## 2. Install System Packages

```bash
sudo apt update && sudo apt upgrade -y

sudo apt install -y software-properties-common curl git unzip nginx mysql-server

sudo add-apt-repository ppa:ondrej/php -y
sudo apt update

sudo apt install -y php8.3 php8.3-fpm php8.3-mysql php8.3-mbstring \
  php8.3-xml php8.3-curl php8.3-bcmath php8.3-zip php8.3-gd php8.3-cli

# Composer
curl -sS https://getcomposer.org/installer | php
sudo mv composer.phar /usr/local/bin/composer
```

---

## 3. Create the Database

```bash
sudo mysql -u root -p
```

```sql
CREATE DATABASE jmwifi_billing CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'jmwifi_user'@'localhost' IDENTIFIED BY 'CHANGE_ME_STRONG_PASSWORD';
GRANT ALL PRIVILEGES ON jmwifi_billing.* TO 'jmwifi_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

---

## 4. Deploy the Application Code

```bash
sudo mkdir -p /var/www/jmwifi-billing
sudo chown $USER:$USER /var/www/jmwifi-billing
cd /var/www/jmwifi-billing

# Copy the project files here (scp, git clone, or upload the zip and unzip it)
# Then:

composer install --optimize-autoloader --no-dev

cp .env.example .env
php artisan key:generate
```

Edit `.env` and fill in:
- `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD` (from Step 3)
- `APP_URL` (your real domain, e.g. `https://billing.jmwifi.com`)
- `PAYMONGO_SECRET_KEY`, `PAYMONGO_PUBLIC_KEY`, `PAYMONGO_WEBHOOK_SECRET` (Section 7)
- `GOOGLE_MAPS_API_KEY` (Section 8, optional but needed for the map page)

---

## 5. Run Migrations, Seed, and Set Permissions

```bash
php artisan migrate
php artisan db:seed                  # creates default admin/staff logins
php artisan storage:link

sudo chown -R www-data:www-data /var/www/jmwifi-billing
sudo chmod -R 755 /var/www/jmwifi-billing
sudo chmod -R 775 storage bootstrap/cache
```

**Default Admin Login** (created by the seeder — change immediately):
- Email: `admin@jmwifi.local`
- Password: `ChangeMe!2026`

**Default Staff Login**:
- Email: `staff@jmwifi.local`
- Password: `StaffPass!2026`

Change both passwords from Admin → Settings right after first login.

---

## 6. Configure Nginx + HTTPS

`/etc/nginx/sites-available/jmwifi-billing`:

```nginx
server {
    listen 80;
    server_name billing.jmwifi.com;
    root /var/www/jmwifi-billing/public;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.3-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/jmwifi-billing /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx

# HTTPS via Let's Encrypt
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d billing.jmwifi.com
```

PayMongo webhooks **will not work over plain HTTP** — HTTPS is mandatory before you continue to Section 7.

---

## 7. Enable MikroTik RouterOS API

On the MikroTik router itself (via Winbox or terminal):

```routeros
/ip service enable api
/ip service set api port=8728

# Create a dedicated API user (don't reuse your main admin account)
/user group add name=billing-api policy=api,read,write,test
/user add name=billing-api password=CHANGE_ME group=billing-api
```

If the router is behind NAT/firewall, make sure port 8728 (or 8729 for SSL) is
reachable from your VPS — either by VPN/site-to-site tunnel (recommended) or
a firewall rule restricted to your VPS's IP only. **Never expose the API port
to the open internet.**

In the billing system: **Admin → Routers → Add Router**, enter the IP, port,
`billing-api` username/password, then click **Test Connection**.

### Required RouterOS objects

**For PPPoE clients**, create the expired profile once:
```routeros
/ppp/profile add name=EXPIRED local-address=10.10.10.1 remote-address=expired-pool rate-limit=128k/128k
```
(Point `EXPIRED`'s rate-limit/pool at whatever "redirect to payment portal" setup you use — a captive portal pool, or just a heavily throttled profile, depending on your network design.)

**For IPoE/DHCP clients**, create the expired address-list and a firewall rule that redirects/blocks it:
```routeros
/ip firewall address-list add list=EXPIRED-CLIENTS address=0.0.0.0/32 comment="placeholder - real entries added by billing system"
/ip firewall nat add chain=dstnat src-address-list=EXPIRED-CLIENTS protocol=tcp dst-port=80,443 action=redirect to-ports=8080 comment="Redirect expired clients to payment portal"
```
Adjust the redirect target to point at your billing system's expired-portal page, or simply `action=drop` if you prefer a hard cutoff instead of a captive-portal redirect.

---

## 8. Get a Google Maps API Key

1. Go to https://console.cloud.google.com/google/maps-apis
2. Create a project (or use an existing one)
3. Enable **Maps JavaScript API**
4. Create an API key, restrict it to your domain (HTTP referrer restriction)
5. Paste it into `.env` as `GOOGLE_MAPS_API_KEY`

---

## 9. Set Up PayMongo (GCash)

1. Create a PayMongo account: https://dashboard.paymongo.com
2. Go to **Developers → API Keys**, copy your **Secret Key** and **Public Key** into `.env`
3. Go to **Developers → Webhooks**, click **Add Webhook**:
   - URL: `https://billing.jmwifi.com/webhooks/paymongo`
   - Events: `checkout_session.payment.paid`, `payment.paid`, `payment.failed`
4. Copy the generated **Webhook Secret** into `.env` as `PAYMONGO_WEBHOOK_SECRET`
5. Go to **Settings → Payment Methods** and ensure **GCash** is enabled
6. Start with **Test Mode** keys (`sk_test_...`) until you've completed the Testing Guide, then switch to live keys (`sk_live_...`) for production

---

## 10. Queue Worker (background jobs)

Reconnects, suspensions, and router syncs run as queued jobs so the web
requests stay fast. Run a worker as a persistent background process using
systemd:

`/etc/systemd/system/jmwifi-queue.service`:

```ini
[Unit]
Description=JM WIFI Billing Queue Worker
After=network.target mysql.service

[Service]
User=www-data
WorkingDirectory=/var/www/jmwifi-billing
ExecStart=/usr/bin/php artisan queue:work --sleep=3 --tries=5 --max-time=3600
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable jmwifi-queue
sudo systemctl start jmwifi-queue
sudo systemctl status jmwifi-queue
```

---

## 11. Scheduler (cron)

The scheduled tasks (5-minute MikroTik sync, daily expiration check,
expiry warnings) are defined in `routes/console.php`. They only run if cron
calls Laravel's scheduler every minute:

```bash
crontab -e -u www-data
```

Add:
```
* * * * * cd /var/www/jmwifi-billing && php artisan schedule:run >> /dev/null 2>&1
```

---

## 12. Verify Everything

```bash
# Check scheduled tasks are registered
php artisan schedule:list

# Manually trigger a router sync to confirm connectivity
php artisan mikrotik:sync

# Manually trigger the expiry check (safe to run any time — it's idempotent)
php artisan clients:check-expired

# Check the queue worker is processing
sudo systemctl status jmwifi-queue
```

Then visit `https://billing.jmwifi.com/login` and sign in with the default
admin account.

---

## 13. Production Hardening Checklist

- [ ] Changed default admin and staff passwords
- [ ] `APP_DEBUG=false` in `.env`
- [ ] `.env` file permissions are `640`, owned by `www-data`
- [ ] MikroTik API not exposed to the public internet
- [ ] PayMongo keys switched from `sk_test_` to `sk_live_` only after full testing
- [ ] MySQL backups scheduled (e.g. nightly `mysqldump` to off-server storage)
- [ ] HTTPS certificate auto-renewal confirmed (`sudo certbot renew --dry-run`)
- [ ] Firewall (ufw) allows only 22, 80, 443
